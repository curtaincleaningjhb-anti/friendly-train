# VOICE ACTOR HIRING TEMPLATE
## Ready-to-Post Job Description for Fiverr/Voices.com

---

## 📋 FIVERR JOB POST (Copy & Paste)

### Title:
```
South African Female Voice for AI Brand Ambassador (40s, Professional, Corporate)
```

### Budget:
```
$100 - $200 USD
```

### Category:
```
Music & Audio > Voice Over > Spokesperson
```

### Description:

```
🎤 PROJECT: AI Avatar Voice for Premium Curtain Cleaning Brand

I need a professional South African female voice actor to record scripts for an AI-powered brand ambassador. This voice will be used to create videos for our luxury curtain cleaning service in Johannesburg.

📊 PROJECT DETAILS:

Character: Thandi Mbatha
Age Sound: Early 40s (mature, professional, trustworthy)
Accent: Authentic South African English (not exaggerated, clear pronunciation)
Tone: Warm, professional, confident but approachable
Industry: Home services / Premium cleaning

🎯 REQUIREMENTS:

✅ Native South African accent (General SA English, not heavy Afrikaans or regional)
✅ Sounds 40-45 years old (mature professional, not young)
✅ Experience with corporate/professional voice work
✅ Clear, professional recording quality
✅ Ability to sound warm yet authoritative
✅ Can pronounce Johannesburg place names correctly (Sandton, Hyde Park, Morningside, etc.)

📝 DELIVERABLES:

1. 3-5 minutes of recorded speech (multiple short scripts)
2. Various emotional tones: welcoming, professional, excited, reassuring
3. File format: WAV, 48kHz, Mono
4. Clean audio - no background noise, echo, or artifacts
5. Full commercial usage rights (including AI voice cloning)

🎬 USAGE:

Your voice will be cloned using AI (ElevenLabs/D-ID) to create unlimited video content for marketing. This is legal and ethical - we just need your voice as the "seed" for the AI system. You will be credited as the voice of our brand ambassador.

💰 BUDGET: $100-200 USD depending on experience and demo quality

⏰ TIMELINE: Need delivery within 5-7 days

📌 TO APPLY:

1. Share your voice demo reel (MUST include South African accent examples)
2. Confirm you sound age 40+ (mature professional tone)
3. Confirm you can provide WAV files at 48kHz
4. Confirm commercial AI usage rights are included
5. Tell me your turnaround time

❌ PLEASE DO NOT APPLY IF:

- You're not a native South African English speaker
- You sound too young (under 35)
- Your accent is heavy Afrikaans or too regional
- You can't provide clean, professional recording quality
- You can't grant AI voice cloning rights

🌟 BONUS POINTS:

- Previous corporate/professional voice work
- Experience with brand ambassador roles
- Understanding of South African business culture
- Quick turnaround time

I'm looking for THE voice of our brand - someone who can represent luxury, trust, and professionalism to Johannesburg's affluent suburbs. If that's you, I'd love to hear your demo!

Looking forward to working with you! 🎙️
```

---

## 📧 FOLLOW-UP MESSAGE TEMPLATE (After They Apply)

```
Hi [Name],

Thanks for your interest in voicing Thandi Mbatha!

Your demo sounds great. Before I place the order, I'd like to request a quick 30-second custom test recording to make sure it's the perfect fit.

Could you please record this short script with warm, professional energy:

---

"Good day! I'm Thandi Mbatha with On The Spot Curtain Cleaning and Service. We're Johannesburg's premier on-site specialists, serving Sandton, Hyde Park, and Morningside. Let me show you how we transform your curtains without ever taking them down."

---

Please send as:
- MP3 or WAV
- Your normal recording quality
- Natural, conversational tone (not overly enthusiastic)

If this sounds good, I'll place the full order immediately!

Thanks,
Steve
On The Spot Curtain Cleaning
```

---

## 📋 VOICES.COM JOB POST

### Project Title:
```
South African Female Voice - AI Brand Ambassador (Corporate, 40s)
```

### Project Type:
```
Commercial - Corporate/Spokesperson
```

### Usage:
```
Online Video, Social Media, Website, All Media
Rights: Perpetual (including AI voice cloning)
```

### Budget:
```
$100 - $200 USD per finished minute
```

### Description:

```
Seeking authentic South African female voice talent (sounds 40-45 years old) for AI brand ambassador role.

PROJECT:
Premium curtain cleaning service in Johannesburg needs a professional, warm voice to represent our brand through AI-generated videos.

CHARACTER:
Thandi Mbatha - mature professional, trustworthy, knowledgeable about luxury home services

REQUIREMENTS:
- Native South African English accent
- Sounds mature (40-45 age range)
- Professional corporate delivery
- Can pronounce SA place names (Johannesburg, Sandton, Hyde Park)
- Experience with spokesperson/corporate work

DELIVERABLES:
- 3-5 minutes of recorded speech
- Multiple scripts (service descriptions, welcomes, suburb spotlights)
- WAV format, 48kHz, mono
- Commercial rights including AI voice cloning

SPECIAL NOTE:
Voice will be used to train AI system (ElevenLabs/D-ID) for unlimited video generation. Full credit and compensation provided.

Timeline: 5-7 days
Budget: $100-200 USD

Please include SA accent samples in your audition!
```

---

## 🎤 SCRIPT FOR TEST RECORDING (Send to Finalists)

```
THANDI MBATHA - VOICE TEST RECORDING
Please record all 4 sections below in one continuous file (about 90 seconds total)

---

SECTION 1: WELCOMING (Warm, friendly)

Good day! I'm Thandi Mbatha with On The Spot Curtain Cleaning and Service. We're Johannesburg's premier on-site curtain cleaning specialists, and I'm so pleased to welcome you today.

---

SECTION 2: PROFESSIONAL (Informative, confident)

We serve Sandton, Hyde Park, Morningside, Bryanston, and surrounding areas with the most advanced curtain cleaning technology available. Our process deep-cleans every fiber while your curtains remain hanging - no removal, no hassle, no weeks waiting for dry cleaners.

---

SECTION 3: ENTHUSIASTIC (Excited, engaging)

Look at this transformation! These curtains went from dull and dusty to absolutely beautiful in just three hours. The colors are vibrant again, the fabric drapes perfectly, and our client saved sixty percent compared to traditional dry cleaning.

---

SECTION 4: CALL-TO-ACTION (Encouraging, direct)

Ready to experience the On The Spot difference? Book your appointment today and discover why Johannesburg's most discerning homeowners trust us with their homes. Visit us online or call now - we're ready to serve you!

---

RECORDING NOTES:
- Natural conversational tone throughout
- Vary energy level between sections
- Clear pronunciation of place names
- WAV or high-quality MP3
- 90 seconds total approximately

Thank you!
```

---

## ✅ EVALUATION CHECKLIST

When reviewing voice actor submissions, rate each 1-10:

### Technical Quality (30 points)
- [ ] Recording quality (clean, no noise) /10
- [ ] Audio levels (consistent, not too loud/quiet) /10
- [ ] File format correct (WAV 48kHz) /10

### Voice Characteristics (40 points)
- [ ] Authentic SA accent (not forced or exaggerated) /10
- [ ] Age-appropriate sound (40s, not 20s) /10
- [ ] Professional tone (corporate, trustworthy) /10
- [ ] Warmth and approachability /10

### Performance (30 points)
- [ ] Energy level (engaged, not flat) /10
- [ ] Emotional range (can vary tone) /10
- [ ] Clarity and articulation /10

**Minimum Score to Hire**: 75/100
**Ideal Score**: 85+/100

---

## 💵 PAYMENT MILESTONES

### For Fiverr:
```
Milestone 1 (50%): Upon delivery of initial recording
Milestone 2 (50%): Upon approval and receipt of final files
```

### For Direct Hire:
```
Deposit (30%): Upon agreement, before recording
Balance (70%): Upon delivery of approved final files
```

### Include in Contract:
- Full commercial usage rights
- Perpetual license
- AI voice cloning rights
- No royalties or residuals
- All rights assigned to On The Spot

---

## 📄 RIGHTS & USAGE AGREEMENT TEMPLATE

```
VOICE OVER USAGE AGREEMENT

This agreement grants On The Spot Curtain Cleaning (Pty) Ltd full commercial rights to:

1. Use the recorded voice for AI voice cloning and generation
2. Create unlimited derivative works using AI systems (D-ID, ElevenLabs, etc.)
3. Use across all media: web, social media, TV, radio, print, presentations
4. Perpetual usage without time limits
5. Transfer or assign rights as needed
6. No additional payments, royalties, or residuals required

The voice actor retains:
- Credit as "Voice of Thandi Mbatha" (if desired)
- Portfolio usage rights (may showcase work in demos)

Agreed:

Voice Actor: _____________________ Date: _______
On The Spot: _____________________ Date: _______
```

---

## 🎯 TOP 3 RECOMMENDED FIVERR SELLERS (Check Current Rankings)

### Search Strategy:
1. Go to Fiverr.com
2. Search: "South African voice over"
3. Filter:
   - ✅ Pro Sellers only
   - ✅ Level 2 or Top Rated
   - ✅ 4.9+ stars
   - ✅ 500+ reviews
   - ✅ Female voice

### What to Look For:
- Demo reel includes professional corporate work
- Reviews mention "professional", "clear", "great communication"
- Quick response time (usually under 24 hours)
- Portfolio shows similar projects
- Offers revisions

### Red Flags to Avoid:
- ❌ New sellers with no reviews
- ❌ Only young voices in demos
- ❌ Exaggerated or theatrical delivery
- ❌ Poor audio quality in samples
- ❌ No SA accent samples

---

## ⏰ TIMELINE EXPECTATIONS

### Typical Process:
- **Day 1**: Post job, receive applications
- **Day 2-3**: Review demos, request test recordings
- **Day 4-5**: Select finalist, place order
- **Day 6-8**: Receive recordings, request any revisions
- **Day 9-10**: Approve final delivery, upload to ElevenLabs

### Rush Option:
- Pay 30-50% extra for 48-hour turnaround
- Only available from some sellers
- Higher risk of quality issues

### Recommended:
- Allow 7-10 days total
- Don't rush - the voice is crucial to your brand
- Test thoroughly before approving

---

## 🎙️ ALTERNATIVE: LOCAL SA VOICE ACTORS

### The Voice Realm (South Africa)
Website: https://www.thevoicerealm.com

**Advantages**:
- All South African based
- Understand local nuances
- Easy communication (same timezone)
- Support local talent

**Process**:
1. Browse talent profiles
2. Listen to demos
3. Contact directly through platform
4. Negotiate rate (typically R800-R2,500)
5. Receive recording via platform

### Voice Architects (Johannesburg)
Contact: info@voicearchitects.co.za

**Services**:
- Professional voice casting
- Studio recording available
- Quick turnaround
- Local references

---

## 💡 MONEY-SAVING TIP

**Get Multiple Uses from One Session**:

When hiring voice actor, record:
1. All Thandi scripts (current)
2. Seasonal variations (Spring, Summer, Winter campaigns)
3. Alternative greetings and sign-offs
4. FAQ answers
5. Suburb variations (all 10+ areas)

Total: 5-8 minutes of speech = enough for 50+ different videos

Cost: Same $100-200 for one session
Value: Unlimited video generation for 1+ years

---

**Ready to hire? Use these templates and you'll have Thandi's voice recorded within a week!** 🎤

For questions about the hiring process, let me know!
