# THANDI MBATHA - MASTER VOICE-OVER RECORDING SCRIPT
## On The Spot Curtain Cleaning & Service
### Professional AI Avatar Voice Recording Session

---

## 📋 RECORDING INFORMATION

**Character**: Thandi Mbatha  
**Age**: Early 40s (mature, professional)  
**Accent**: South African English (authentic, not exaggerated)  
**Tone**: Warm, professional, confident yet approachable  
**Industry**: Premium home services / Luxury curtain cleaning  

**Total Recording Time**: Approximately 8-10 minutes  
**Purpose**: AI voice cloning for unlimited video content generation  
**Usage**: Website videos, social media, email marketing, YouTube  

---

## 🎤 RECORDING INSTRUCTIONS FOR VOICE ACTOR

### Technical Requirements:
- **Format**: WAV, 48kHz, Mono
- **Recording Space**: Quiet room, no echo or background noise
- **Microphone Distance**: 6-8 inches from mouth
- **Volume**: Consistent levels throughout (normalize to -3dB)
- **Delivery**: Natural conversational tone, smile while speaking

### Performance Notes:
- **Energy Level**: Medium-high (engaged, not hyperactive)
- **Pace**: Moderate (slower than casual conversation, but not unnaturally slow)
- **Emphasis**: Natural stress on brand names and key benefits
- **Emotion**: Genuine warmth without being overly enthusiastic
- **Character**: Trusted advisor, knowledgeable professional, caring expert

### Special Pronunciation:
- **Johannesburg**: jo-HAN-nes-burg (stress second syllable)
- **Sandton**: SAND-ton (not "Sand-town")
- **On The Spot**: Slight emphasis on "Spot" (brand pride)
- **Good day**: Traditional SA greeting - warm, welcoming

---

## 🎯 RECORDING SESSION STRUCTURE

**SECTION 1**: Warm-up & Test Phrases (1 minute)  
**SECTION 2**: Core Introduction Scripts (2 minutes)  
**SECTION 3**: Service Explanations (2 minutes)  
**SECTION 4**: Suburb-Specific Content (1.5 minutes)  
**SECTION 5**: Emotional Variations (1.5 minutes)  
**SECTION 6**: Short-Form Content (1 minute)  
**SECTION 7**: Calls-to-Action (1 minute)  

**TOTAL**: ~9-10 minutes of recorded content

---

## 🔥 SECTION 1: WARM-UP & TEST PHRASES (1 minute)

### Purpose: Voice calibration, pronunciation check, energy level test

**[Read naturally, conversationally]**

---

### Test Phrase 1 - Brand Introduction
*Tone: Professional, warm*

> "Good day! I'm Thandi Mbatha with On The Spot Curtain Cleaning and Service."

**[PAUSE 2 SECONDS]**

---

### Test Phrase 2 - Place Names
*Tone: Professional, clear pronunciation*

> "We serve Johannesburg's premier suburbs: Sandton, Hyde Park, Morningside, Bryanston, Illovo, and Rosebank."

**[PAUSE 2 SECONDS]**

---

### Test Phrase 3 - Key Benefits
*Tone: Enthusiastic but controlled*

> "No removal, no re-hanging, no hassle. Just beautifully clean curtains in your home, the same day."

**[PAUSE 2 SECONDS]**

---

### Test Phrase 4 - Emotional Range
*Tone: Excited, showing transformation*

> "Look at this transformation! These curtains went from dull and dusty to absolutely beautiful in just three hours."

**[PAUSE 5 SECONDS - END OF WARM-UP]**

---

## 📢 SECTION 2: CORE INTRODUCTION SCRIPTS (2 minutes)

### Purpose: Main welcome and introduction videos for website homepage

---

### Script 2A - Full Welcome Introduction (45 seconds)
*Tone: Welcoming, professional, building trust*

**[Begin recording]**

> "Good day! I'm Thandi Mbatha with On The Spot Curtain Cleaning and Service, and I'm so pleased to welcome you.
> 
> For over a decade, we've been helping Johannesburg families and businesses keep their curtains, mattresses, and upholstery absolutely pristine - without the hassle of traditional cleaning methods.
> 
> Here's what makes us different: We come to your home or office, and we clean your curtains right where they hang. No taking them down, no re-hanging, no weeks waiting for dry cleaners.
> 
> You save time. You save money - up to sixty percent compared to traditional dry cleaning. And you get professional results that last.
> 
> Whether you're in Sandton, Hyde Park, Morningside, or anywhere across Johannesburg, we're ready to serve you. Let me show you what truly clean curtains look like."

**[PAUSE 3 SECONDS]**

---

### Script 2B - Quick Introduction (30 seconds)
*Tone: Energetic, efficient, direct*

**[Begin recording]**

> "Hi! I'm Thandi Mbatha with On The Spot Curtain Cleaning and Service.
>
> We're Johannesburg's premier on-site curtain cleaning specialists, serving Sandton, Hyde Park, Morningside, and surrounding areas.
>
> We clean your curtains right where they hang - no removal, no hassle, no weeks of waiting. Just beautiful, fresh curtains, the same day.
>
> You save up to sixty percent compared to dry cleaning, and you get professional results you can trust.
>
> Book your appointment today and discover the On The Spot difference."

**[PAUSE 3 SECONDS]**

---

### Script 2C - Brand Promise (20 seconds)
*Tone: Confident, reassuring, brand-focused*

**[Begin recording]**

> "On The Spot means exactly that - we come to your spot. Your home. Your office. Your schedule.
>
> No packing. No transporting. No waiting. Just professional curtain cleaning that comes to you.
>
> That's the On The Spot promise."

**[PAUSE 5 SECONDS - END OF SECTION 2]**

---

## 🛠️ SECTION 3: SERVICE EXPLANATIONS (2 minutes)

### Purpose: Detailed service descriptions for educational content

---

### Script 3A - On-Site Curtain Cleaning Process (60 seconds)
*Tone: Educational, knowledgeable, patient*

**[Begin recording]**

> "Let me explain exactly how our on-site curtain cleaning works - because it's quite remarkable.
>
> We use specialized, hospital-grade cleaning equipment that's been designed specifically for fabric care. Our process deep-cleans every fiber while your curtains remain hanging on their rails.
>
> First, we assess your curtains - the fabric type, any stains or problem areas, and the specific care they need.
>
> Second, we pre-treat any spots or stains using eco-friendly, fabric-safe solutions.
>
> Third, our deep-cleaning process removes dust, pollen, allergens, smoke residue, and that stubborn Johannesburg pollution that builds up over time.
>
> The entire process typically takes two to four hours depending on the number of curtains. You can be home or away - whatever suits your schedule.
>
> When we're finished, your curtains are fresh, clean, and ready to enjoy. No removal. No damage to delicate fabrics. No disruption to your home."

**[PAUSE 3 SECONDS]**

---

### Script 3B - Mattress Sanitization (40 seconds)
*Tone: Health-focused, caring, informative*

**[Begin recording]**

> "While we're discussing complete home care, let me share something important about your mattresses.
>
> We spend a third of our lives in bed. But your mattress can harbor dust mites, allergens, dead skin cells, and odors that you can't see or smell - until they become a problem.
>
> Our mattress sanitization service uses the same hospital-grade equipment as our curtain cleaning. We deep-clean and sanitize, removing allergens and bacteria.
>
> Better sleep quality. Reduced allergies. Extended mattress life. And a fresher, healthier bedroom environment.
>
> Many of our clients bundle curtain and mattress cleaning on the same day. It's convenient, cost-effective, and gives you complete peace of mind."

**[PAUSE 3 SECONDS]**

---

### Script 3C - Why Choose On The Spot (30 seconds)
*Tone: Confident, benefit-focused, persuasive*

**[Begin recording]**

> "Why choose On The Spot? Three simple reasons.
>
> First - convenience. We come to your home or office at a time that suits you. No packing, no transporting, no disruption.
>
> Second - savings. You save up to sixty percent compared to traditional dry cleaning, with the same professional results.
>
> Third - expertise. Over a decade serving Johannesburg's most discerning clients. We know fabrics, we know cleaning, and we know how to deliver excellence.
>
> That's why we're the trusted choice for Sandton, Hyde Park, and Morningside."

**[PAUSE 5 SECONDS - END OF SECTION 3]**

---

## 🏘️ SECTION 4: SUBURB-SPECIFIC CONTENT (1.5 minutes)

### Purpose: Personalized messaging for different Johannesburg suburbs

---

### Script 4A - Sandton (30 seconds)
*Tone: Upscale, understanding, respectful*

**[Begin recording]**

> "To my Sandton neighbors - I know your lifestyle.
>
> Your days are full. Your home is your sanctuary. And those beautiful floor-to-ceiling curtains in your townhouse or estate? They deserve the very best care.
>
> We understand that for you, convenience isn't a luxury - it's essential. That's why we've built our entire service around your needs.
>
> Same-week appointments. Flexible scheduling. And we work quietly and efficiently, respecting your space.
>
> Book your appointment today, and discover why Sandton's most discerning homeowners choose On The Spot."

**[PAUSE 3 SECONDS]**

---

### Script 4B - Hyde Park (25 seconds)
*Tone: Community-focused, warm, neighborly*

**[Begin recording]**

> "Hyde Park families, this message is for you.
>
> Your neighborhood is special - tree-lined streets, beautiful homes, a real sense of community. We've been proud to serve Hyde Park residents for years.
>
> Whether it's those gorgeous bay window curtains, your formal dining room drapes, or the nursery curtains in your child's room - we handle every fabric with expert care.
>
> Join your Hyde Park neighbors. Experience the difference professional on-site cleaning makes."

**[PAUSE 3 SECONDS]**

---

### Script 4C - General Suburb Template (20 seconds)
*Tone: Professional, inclusive, warm*

**[Begin recording]**

> "To our clients across Johannesburg - from Morningside to Bryanston, Illovo to Rosebank - we're here for you.
>
> Your beautiful home deserves the very best care. And that's exactly what we deliver. Professional. Convenient. Trustworthy.
>
> We're right here in your area, ready to serve you with the same excellence your neighbors have trusted for years."

**[PAUSE 5 SECONDS - END OF SECTION 4]**

---

## 💫 SECTION 5: EMOTIONAL VARIATIONS (1.5 minutes)

### Purpose: Different emotional tones for various video scenarios

---

### Script 5A - Excited/Enthusiastic (Before/After Reveals) (30 seconds)
*Tone: Excited, genuine amazement, building energy*

**[Begin recording]**

> "Let me show you the remarkable difference we make!
>
> Look at this transformation! These curtains from a Hyde Park home had years of dust, pollen, and pollution. You can see how dull the colors had become.
>
> After just one On The Spot cleaning session? Look at this! Colors restored to their original vibrancy. Every pleat clean and fresh. The fabric drapes beautifully again.
>
> This entire cleaning was done on-site in under three hours. The curtains never left the rails. No removal, no stress, no weeks of waiting.
>
> This is what we do - bring your curtains back to life!"

**[PAUSE 3 SECONDS]**

---

### Script 5B - Reassuring/Caring (Addressing Concerns) (25 seconds)
*Tone: Gentle, understanding, reassuring*

**[Begin recording]**

> "I understand your concerns about delicate fabrics. You should be careful - not all cleaners know how to handle specialty materials.
>
> We clean everything from everyday cotton to precious silk, velvet, and imported linens. Our team is trained in fabric identification and appropriate care methods.
>
> We adjust our equipment, solutions, and techniques based on your specific fabric type. No guesswork - just expert care.
>
> If we can't clean a fabric safely, we'll tell you upfront. Honesty and expertise - that's our promise."

**[PAUSE 3 SECONDS]**

---

### Script 5C - Professional/Corporate (B2B Content) (30 seconds)
*Tone: Business-like, efficient, solution-focused*

**[Begin recording]**

> "Business leaders, let's discuss your professional environment.
>
> Your office space makes a statement to clients, partners, and employees. Clean, well-maintained curtains and upholstery communicate attention to detail and professional standards.
>
> Our commercial on-site service eliminates disruption. We work after hours or on weekends. No impact on your business operations. Professional results that enhance your environment.
>
> We serve law firms, medical practices, corporate offices, and hospitality businesses across Johannesburg.
>
> Request a commercial quote today. Let's discuss how we can serve your business."

**[PAUSE 5 SECONDS - END OF SECTION 5]**

---

## ⚡ SECTION 6: SHORT-FORM CONTENT (1 minute)

### Purpose: Social media clips, quick tips, FAQ responses

---

### Script 6A - FAQ: How Long Does It Take? (15 seconds)
*Tone: Helpful, clear, efficient*

**[Begin recording]**

> "One of our most common questions: 'How long will it take?'
>
> For most homes, curtain cleaning takes between two to four hours, depending on the number of windows. You can be home or away - whatever works for you."

**[PAUSE 2 SECONDS]**

---

### Script 6B - FAQ: Is It Safe for Delicate Fabrics? (15 seconds)
*Tone: Knowledgeable, confident, reassuring*

**[Begin recording]**

> "Is our process safe for delicate fabrics? Absolutely.
>
> We handle silk, velvet, linen, even imported specialty fabrics. Our team adjusts techniques for each fabric type. Professional care you can trust."

**[PAUSE 2 SECONDS]**

---

### Script 6C - Quick Benefit Highlight (10 seconds)
*Tone: Upbeat, benefit-focused*

**[Begin recording]**

> "No removal. No re-hanging. No hassle. Just beautifully clean curtains in your home, the same day. That's the On The Spot advantage."

**[PAUSE 2 SECONDS]**

---

### Script 6D - Social Media Teaser (10 seconds)
*Tone: Friendly, conversational, inviting*

**[Begin recording]**

> "Hi! I'm Thandi with On The Spot. Want to see an incredible before-and-after transformation? Keep watching - you won't believe the difference!"

**[PAUSE 5 SECONDS - END OF SECTION 6]**

---

## 📞 SECTION 7: CALLS-TO-ACTION (1 minute)

### Purpose: Conversion-focused closing statements

---

### Script 7A - Book Now (Strong CTA) (20 seconds)
*Tone: Encouraging, direct, action-oriented*

**[Begin recording]**

> "Ready to experience the On The Spot difference?
>
> Click the button below for an instant online quote - just tell us how many windows you have and your suburb.
>
> Or call us directly. We'll answer your questions and schedule your appointment.
>
> We serve all major Johannesburg suburbs with same-week appointments available. Don't wait - book your On The Spot service today!"

**[PAUSE 2 SECONDS]**

---

### Script 7B - Soft CTA (Informational) (15 seconds)
*Tone: Helpful, non-pushy, inviting*

**[Begin recording]**

> "Have questions about our services? We're here to help.
>
> Visit our website for detailed information, check out our before-and-after gallery, or contact us directly.
>
> We look forward to serving you!"

**[PAUSE 2 SECONDS]**

---

### Script 7C - Limited Time Offer (20 seconds)
*Tone: Excited, urgent but not pushy*

**[Begin recording]**

> "Special offer for new clients - book this month and save!
>
> Twenty percent off your first curtain cleaning service, plus a free mattress inspection when you bundle.
>
> But this offer ends soon. Click below to claim your discount and schedule your appointment.
>
> Don't miss out - transform your home today!"

**[PAUSE 2 SECONDS]**

---

### Script 7D - Thank You / Closing (15 seconds)
*Tone: Warm, grateful, personal*

**[Begin recording]**

> "Thank you for choosing On The Spot Curtain Cleaning and Service.
>
> We're grateful for your trust, and we're committed to exceeding your expectations.
>
> If you have any questions, don't hesitate to reach out. We're here to help.
>
> See you soon!"

**[PAUSE 5 SECONDS - END OF SECTION 7]**

---

## 🎬 RECORDING COMPLETE!

### Total Recording Time: ~9-10 minutes
### Total Word Count: ~2,800 words
### Suitable For: AI voice cloning and unlimited video generation

---

## ✅ POST-RECORDING CHECKLIST

**Voice Actor / Recording Engineer**:
- [ ] Review all recordings for audio quality
- [ ] Check for background noise or artifacts
- [ ] Verify consistent volume levels
- [ ] Normalize audio to -3dB
- [ ] Export as WAV, 48kHz, Mono
- [ ] Include one master file (all sections) + individual section files
- [ ] Remove mouth clicks and excessive breaths
- [ ] Add 1-2 seconds of room tone at beginning

**File Delivery**:
- [ ] Master recording (9-10 minutes, continuous)
- [ ] Individual section files (optional, but helpful)
- [ ] File name format: `Thandi_Mbatha_Master_Recording_[DATE].wav`
- [ ] Backup MP3 version for preview

---

## 📝 USAGE NOTES FOR CLIENT

This recording provides:
- ✅ Enough variety for AI voice cloning (ElevenLabs, D-ID)
- ✅ Multiple emotional tones and energy levels
- ✅ All core scripts for immediate video production
- ✅ Material for 50+ unique videos
- ✅ Suburb-specific customization ready
- ✅ Short-form and long-form content
- ✅ Professional and conversational variations

**Next Steps After Recording**:
1. Upload to ElevenLabs for voice cloning
2. Use cloned voice with D-ID for video generation
3. Generate videos using scripts from library
4. Deploy across website, social media, and email

---

## 🎤 FINAL PERFORMANCE TIPS

**Energy Management**:
- Start fresh - don't record when tired
- Take breaks between sections
- Hydrate frequently (room temp water)
- Maintain consistent energy throughout

**Emotional Authenticity**:
- Smile while speaking (it changes vocal tone)
- Imagine speaking to a real client
- Visualize the transformation you're describing
- Let genuine warmth come through

**Technical Excellence**:
- Monitor audio levels constantly
- Listen back after each section
- Re-record any takes with issues
- Aim for perfection - this represents the brand

---

**Thank you for bringing Thandi Mbatha to life!**

**This voice will represent On The Spot Curtain Cleaning across all marketing channels and will be heard by thousands of potential clients. Your performance matters!**

---

**Questions during recording? Contact: [YOUR CONTACT INFO]**

**File delivery: [EMAIL/DROPBOX/WETRANSFER LINK]**

**Payment upon approval of final files**

---

## 📧 EMAIL THIS COMPLETE SCRIPT TO YOUR VOICE ACTOR

**Subject**: Voice Recording Script - Thandi Mbatha - On The Spot

**Attachment**: This complete script (PDF format recommended)

**Include**:
- Recording deadline
- File delivery method
- Payment terms
- Your contact information
- Any special instructions

---

**SCRIPT VERSION**: 1.0  
**CREATED**: January 2026  
**CHARACTER**: Thandi Mbatha  
**CLIENT**: On The Spot Curtain Cleaning & Service  
**TOTAL DURATION**: 9-10 minutes  
**USAGE**: AI Voice Cloning & Video Generation
