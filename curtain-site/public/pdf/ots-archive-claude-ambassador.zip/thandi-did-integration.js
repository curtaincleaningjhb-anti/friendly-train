// ========================================
// ON THE SPOT - D-ID AVATAR INTEGRATION
// Complete API Implementation & Automation
// ========================================

// ==================
// 1. CONFIGURATION
// ==================

const CONFIG = {
  // D-ID API Credentials
  DID_API_KEY: process.env.DID_API_KEY || 'YOUR_D-ID_API_KEY_HERE',
  DID_API_ENDPOINT: 'https://api.d-id.com',
  
  // Avatar Settings
  AVATAR_IMAGE_URL: 'https://yourdomain.com/thandi-full-body.jpg',
  
  // Voice Settings (ElevenLabs Integration)
  ELEVENLABS_API_KEY: process.env.ELEVENLABS_API_KEY || 'YOUR_ELEVENLABS_KEY',
  ELEVENLABS_VOICE_ID: 'south-african-female-40s', // Custom voice ID
  
  // Brand Settings
  BRAND_COLORS: {
    navy: '#1e3a8a',
    gold: '#d4af37',
    white: '#ffffff'
  },
  
  // Video Settings
  VIDEO_CONFIG: {
    format: 'mp4',
    resolution: '1080p',
    aspectRatio: '16:9', // or '9:16' for vertical, '1:1' for square
    fps: 30
  }
};

// ==================
// 2. D-ID API CLIENT
// ==================

class DIDClient {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.baseUrl = CONFIG.DID_API_ENDPOINT;
  }

  // Generate authorization header
  getAuthHeader() {
    return {
      'Authorization': `Basic ${Buffer.from(`${this.apiKey}:`).toString('base64')}`,
      'Content-Type': 'application/json'
    };
  }

  // Create a talking avatar video
  async createTalk(script, options = {}) {
    const {
      avatarUrl = CONFIG.AVATAR_IMAGE_URL,
      voiceId = CONFIG.ELEVENLABS_VOICE_ID,
      provider = 'elevenlabs',
      background = null,
      stitch = true
    } = options;

    const payload = {
      script: {
        type: 'text',
        input: script,
        provider: {
          type: provider,
          voice_id: voiceId
        }
      },
      source_url: avatarUrl,
      config: {
        stitch: stitch, // Enable full-body movement
        result_format: CONFIG.VIDEO_CONFIG.format,
        ...(background && { background })
      }
    };

    try {
      const response = await fetch(`${this.baseUrl}/talks`, {
        method: 'POST',
        headers: this.getAuthHeader(),
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`D-ID API Error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      console.log('✅ Video generation started:', data.id);
      return data;
    } catch (error) {
      console.error('❌ Error creating talk:', error);
      throw error;
    }
  }

  // Get video status
  async getTalkStatus(talkId) {
    try {
      const response = await fetch(`${this.baseUrl}/talks/${talkId}`, {
        method: 'GET',
        headers: this.getAuthHeader()
      });

      if (!response.ok) {
        throw new Error(`D-ID API Error: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('❌ Error getting talk status:', error);
      throw error;
    }
  }

  // Poll until video is ready
  async waitForVideoCompletion(talkId, maxWaitMs = 300000, pollIntervalMs = 5000) {
    const startTime = Date.now();
    
    while (Date.now() - startTime < maxWaitMs) {
      const status = await this.getTalkStatus(talkId);
      
      console.log(`🔄 Status: ${status.status}`);
      
      if (status.status === 'done') {
        console.log('✅ Video ready!');
        return status;
      } else if (status.status === 'error') {
        throw new Error(`Video generation failed: ${status.error}`);
      }
      
      // Wait before polling again
      await new Promise(resolve => setTimeout(resolve, pollIntervalMs));
    }
    
    throw new Error('Video generation timeout');
  }

  // Download completed video
  async downloadVideo(videoUrl, outputPath) {
    const response = await fetch(videoUrl);
    const buffer = await response.arrayBuffer();
    const fs = require('fs').promises;
    await fs.writeFile(outputPath, Buffer.from(buffer));
    console.log(`✅ Video saved to: ${outputPath}`);
  }

  // Delete a talk (cleanup)
  async deleteTalk(talkId) {
    try {
      await fetch(`${this.baseUrl}/talks/${talkId}`, {
        method: 'DELETE',
        headers: this.getAuthHeader()
      });
      console.log(`🗑️ Deleted talk: ${talkId}`);
    } catch (error) {
      console.error('❌ Error deleting talk:', error);
    }
  }
}

// ==================
// 3. SCRIPT LIBRARY
// ==================

const SCRIPT_TEMPLATES = {
  welcome: `Good day! I'm Thandi Mbatha with On The Spot Curtain Cleaning and Service. We're Johannesburg's premium on-site curtain cleaning specialists, serving Sandton, Hyde Park, Morningside, and surrounding areas. Today, I'll show you how we can transform your curtains without ever taking them down - saving you time, money, and hassle.`,
  
  sandton: `To my Sandton neighbors - I know your lifestyle. Your days are full. Your home is your sanctuary. And those beautiful floor-to-ceiling curtains in your townhouse or estate? They deserve the very best care. We understand that for you, convenience isn't a luxury - it's essential. Book your appointment today, and discover why Sandton's most discerning homeowners choose On The Spot.`,
  
  hydePark: `Hyde Park families, this message is for you. Your neighborhood is special - tree-lined streets, beautiful homes, a real sense of community. Whether it's those gorgeous bay window curtains, your formal dining room drapes, or the nursery curtains in your child's room - we handle every fabric with expert care. Join your Hyde Park neighbors. Experience the difference.`,
  
  beforeAfter: `Let me show you the remarkable difference we make. These curtains from a Hyde Park home had years of dust, pollen, and pollution. After just one On The Spot cleaning session? Look at this transformation! Colors restored, every pleat clean and fresh, the fabric drapes beautifully again. This entire cleaning was done on-site in under three hours.`,
  
  mattress: `While we're discussing complete home care, let me share something important about your mattresses. We spend a third of our lives in bed, but your mattress can harbor dust mites, allergens, and bacteria. Our sanitization service uses hospital-grade equipment. Better sleep quality, reduced allergies, extended mattress life. Many clients bundle both services for convenience.`,
  
  cta: `Ready to experience the On The Spot difference? Click the button below for an instant quote. We serve all major Johannesburg suburbs with same-week appointments available. Let us show you what truly clean curtains look like. Book your appointment today!`,
  
  // Dynamic template generator
  suburb: (suburbName) => `To our ${suburbName} neighbors - we understand your lifestyle and respect your time. Your beautiful home deserves the very best care, and that's exactly what we deliver. We're right here in your area, ready to serve you with the same excellence your neighbors have trusted for years.`,
  
  seasonal: (season, offer) => `${season} has arrived in Johannesburg! Now's the perfect time to refresh your home. Our ${season} Special includes ${offer}. Book this month and experience the On The Spot difference. Limited time - don't miss out!`,
  
  testimonial: (clientName, suburb) => `Don't just take my word for it. Listen to what ${clientName} from ${suburb} has to say about their experience with On The Spot.`
};

// ==================
// 4. VIDEO GENERATOR
// ==================

class ThandiVideoGenerator {
  constructor(didClient) {
    this.client = didClient;
    this.outputDir = './generated_videos/';
  }

  // Ensure output directory exists
  async ensureOutputDir() {
    const fs = require('fs').promises;
    try {
      await fs.access(this.outputDir);
    } catch {
      await fs.mkdir(this.outputDir, { recursive: true });
    }
  }

  // Generate a single video
  async generateVideo(scriptKey, options = {}) {
    const {
      customScript = null,
      filename = `thandi_${scriptKey}_${Date.now()}.mp4`,
      downloadVideo = true
    } = options;

    await this.ensureOutputDir();

    const script = customScript || SCRIPT_TEMPLATES[scriptKey];
    
    if (!script) {
      throw new Error(`Script template "${scriptKey}" not found`);
    }

    console.log(`🎬 Generating video: ${scriptKey}`);
    console.log(`📝 Script: ${script.substring(0, 100)}...`);

    // Create the talk
    const talk = await this.client.createTalk(script);
    
    // Wait for completion
    const completed = await this.client.waitForVideoCompletion(talk.id);
    
    // Download if requested
    if (downloadVideo && completed.result_url) {
      const outputPath = `${this.outputDir}${filename}`;
      await this.client.downloadVideo(completed.result_url, outputPath);
      return {
        talkId: talk.id,
        videoUrl: completed.result_url,
        localPath: outputPath,
        script: script
      };
    }

    return {
      talkId: talk.id,
      videoUrl: completed.result_url,
      script: script
    };
  }

  // Generate multiple videos in sequence
  async generateBatch(scriptKeys, options = {}) {
    const results = [];
    
    for (const key of scriptKeys) {
      try {
        const result = await this.generateVideo(key, options);
        results.push({ success: true, key, ...result });
        
        // Brief pause between API calls
        await new Promise(resolve => setTimeout(resolve, 2000));
      } catch (error) {
        console.error(`❌ Failed to generate ${key}:`, error.message);
        results.push({ success: false, key, error: error.message });
      }
    }
    
    return results;
  }

  // Generate suburb-specific videos
  async generateSuburbCampaign(suburbs) {
    const results = [];
    
    for (const suburb of suburbs) {
      const script = SCRIPT_TEMPLATES.suburb(suburb);
      try {
        const result = await this.generateVideo('suburb', {
          customScript: script,
          filename: `thandi_${suburb.toLowerCase().replace(/\s/g, '_')}.mp4`
        });
        results.push({ success: true, suburb, ...result });
        await new Promise(resolve => setTimeout(resolve, 2000));
      } catch (error) {
        console.error(`❌ Failed to generate ${suburb}:`, error.message);
        results.push({ success: false, suburb, error: error.message });
      }
    }
    
    return results;
  }
}

// ==================
// 5. AUTOMATION WORKFLOWS
// ==================

class VideoAutomation {
  constructor(generator) {
    this.generator = generator;
  }

  // Initial website launch - generate core videos
  async generateWebsiteLaunch() {
    console.log('🚀 Generating Website Launch Videos...\n');
    
    const coreVideos = [
      'welcome',
      'sandton',
      'hydePark',
      'beforeAfter',
      'mattress',
      'cta'
    ];

    const results = await this.generator.generateBatch(coreVideos);
    
    console.log('\n📊 Launch Videos Complete:');
    results.forEach(r => {
      console.log(`${r.success ? '✅' : '❌'} ${r.key}`);
    });

    return results;
  }

  // Generate all suburb videos
  async generateAllSuburbVideos() {
    console.log('🏘️ Generating Suburb Campaign Videos...\n');
    
    const suburbs = [
      'Sandton',
      'Hyde Park',
      'Morningside',
      'Bryanston',
      'Illovo',
      'Melrose',
      'Rosebank',
      'Parktown',
      'Houghton',
      'Sandhurst'
    ];

    const results = await this.generator.generateSuburbCampaign(suburbs);
    
    console.log('\n📊 Suburb Videos Complete:');
    results.forEach(r => {
      console.log(`${r.success ? '✅' : '❌'} ${r.suburb}`);
    });

    return results;
  }

  // Monthly content calendar
  async generateMonthlyContent(month) {
    console.log(`📅 Generating ${month} Content...\n`);
    
    // Example: Spring cleaning campaign
    if (month.toLowerCase().includes('spring')) {
      const springScript = SCRIPT_TEMPLATES.seasonal(
        'Spring',
        'curtain cleaning and mattress sanitization at special pricing'
      );
      
      return await this.generator.generateVideo('seasonal', {
        customScript: springScript,
        filename: 'thandi_spring_campaign.mp4'
      });
    }

    // Add more seasonal/monthly campaigns
  }

  // Generate personalized quote video
  async generatePersonalizedQuote(clientName, suburb, quoteDetails) {
    const personalizedScript = `Hi ${clientName}, this is Thandi from On The Spot. Thank you for requesting a quote for your home in ${suburb}. I've reviewed your needs, and I'm excited to help. ${quoteDetails} Click below to confirm your appointment, or reply if you have questions. I look forward to serving you!`;

    return await this.generator.generateVideo('quote', {
      customScript: personalizedScript,
      filename: `thandi_quote_${clientName.replace(/\s/g, '_')}.mp4`
    });
  }
}

// ==================
// 6. USAGE EXAMPLES
// ==================

async function main() {
  // Initialize D-ID client
  const didClient = new DIDClient(CONFIG.DID_API_KEY);
  
  // Initialize video generator
  const generator = new ThandiVideoGenerator(didClient);
  
  // Initialize automation
  const automation = new VideoAutomation(generator);

  // ========================================
  // EXAMPLE 1: Generate a single video
  // ========================================
  /*
  const welcomeVideo = await generator.generateVideo('welcome');
  console.log('Video URL:', welcomeVideo.videoUrl);
  */

  // ========================================
  // EXAMPLE 2: Generate website launch videos
  // ========================================
  /*
  const launchResults = await automation.generateWebsiteLaunch();
  */

  // ========================================
  // EXAMPLE 3: Generate all suburb videos
  // ========================================
  /*
  const suburbResults = await automation.generateAllSuburbVideos();
  */

  // ========================================
  // EXAMPLE 4: Generate custom script video
  // ========================================
  /*
  const customScript = `Good day! This is a custom message for a special client...`;
  const customVideo = await generator.generateVideo('custom', {
    customScript: customScript,
    filename: 'thandi_custom_special.mp4'
  });
  */

  // ========================================
  // EXAMPLE 5: Personalized quote video
  // ========================================
  /*
  const quoteVideo = await automation.generatePersonalizedQuote(
    'Mrs. Naidoo',
    'Sandton',
    'Your quote includes 6 windows of curtain cleaning for R1,800. We can schedule as early as next Tuesday.'
  );
  */

  console.log('✅ Video generation complete!');
}

// ==================
// 7. EXPRESS API ENDPOINTS
// ==================

// If you want to create an API for your website to generate videos on-demand:

const express = require('express');
const app = express();
app.use(express.json());

const didClient = new DIDClient(CONFIG.DID_API_KEY);
const generator = new ThandiVideoGenerator(didClient);

// Generate video endpoint
app.post('/api/generate-video', async (req, res) => {
  try {
    const { scriptKey, customScript, filename } = req.body;
    
    const result = await generator.generateVideo(scriptKey, {
      customScript,
      filename,
      downloadVideo: false // Just return URL
    });

    res.json({
      success: true,
      videoUrl: result.videoUrl,
      talkId: result.talkId
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Generate personalized quote video
app.post('/api/generate-quote-video', async (req, res) => {
  try {
    const { clientName, suburb, quoteDetails } = req.body;
    
    const automation = new VideoAutomation(generator);
    const result = await automation.generatePersonalizedQuote(
      clientName,
      suburb,
      quoteDetails
    );

    res.json({
      success: true,
      videoUrl: result.videoUrl
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Thandi Video API running on port ${PORT}`);
});

// ==================
// 8. WEBHOOK INTEGRATION
// ==================

// Receive webhook notifications when videos are ready
app.post('/webhook/did-callback', async (req, res) => {
  const { id, status, result_url } = req.body;
  
  console.log(`📬 Webhook received for talk ${id}: ${status}`);
  
  if (status === 'done' && result_url) {
    // Video is ready - you could:
    // - Send email to client with video
    // - Update database
    // - Post to social media
    // - Upload to YouTube
    console.log(`✅ Video ready: ${result_url}`);
  }
  
  res.sendStatus(200);
});

// ==================
// 9. EXPORT FOR USE
// ==================

module.exports = {
  DIDClient,
  ThandiVideoGenerator,
  VideoAutomation,
  SCRIPT_TEMPLATES,
  CONFIG
};

// ==================
// 10. CLI TOOL
// ==================

// Run from command line: node thandi-generator.js [command] [options]

if (require.main === module) {
  const args = process.argv.slice(2);
  const command = args[0];

  (async () => {
    const didClient = new DIDClient(CONFIG.DID_API_KEY);
    const generator = new ThandiVideoGenerator(didClient);
    const automation = new VideoAutomation(generator);

    switch (command) {
      case 'welcome':
        await generator.generateVideo('welcome');
        break;
      
      case 'launch':
        await automation.generateWebsiteLaunch();
        break;
      
      case 'suburbs':
        await automation.generateAllSuburbVideos();
        break;
      
      case 'custom':
        const script = args[1];
        await generator.generateVideo('custom', { customScript: script });
        break;
      
      default:
        console.log(`
🎬 Thandi Video Generator CLI

Usage:
  node thandi-generator.js [command] [options]

Commands:
  welcome         Generate welcome video
  launch          Generate all website launch videos
  suburbs         Generate all suburb-specific videos
  custom "text"   Generate video with custom script

Examples:
  node thandi-generator.js welcome
  node thandi-generator.js suburbs
  node thandi-generator.js custom "Hello, this is a test"
        `);
    }

    process.exit(0);
  })();
}
