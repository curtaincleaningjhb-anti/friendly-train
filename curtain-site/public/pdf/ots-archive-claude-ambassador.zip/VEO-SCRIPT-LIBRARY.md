# VEO-OPTIMIZED SCRIPT LIBRARY
## 30-60 Second Scripts for Google Veo Generation
### On The Spot Curtain Cleaning & Service

---

## 📋 IMPORTANT: VEO FORMAT REQUIREMENTS

**Length**: 30-60 seconds MAXIMUM per video
**Word Count**: 75-150 words per script
**Strategy**: Break longer content into series of short videos

---

## 🎬 SECTION 1: WELCOME & INTRODUCTION VIDEOS

### Video 1A - Quick Welcome (30 seconds)
**Word Count**: 75 words

```
Good day! I'm Thandi Mbatha with On The Spot Curtain Cleaning and Service.

We're Johannesburg's premier on-site curtain cleaning specialists, serving 
Sandton, Hyde Park, Morningside, and surrounding areas.

Here's what makes us special: We come to your home or office and clean 
your curtains right where they hang. No removal, no re-hanging, no weeks 
of waiting.

You save time, you save money, and you get professional results. 

Let me show you how we transform homes across Johannesburg.
```

**Veo Prompt**:
```
Professional South African businesswoman, early 40s, navy blue blazer, 
gold jewelry, standing in modern bright office, warm confident smile, 
addressing camera directly:

[INSERT SCRIPT ABOVE]

Corporate video style, professional lighting, photorealistic, 1080p, 
30 seconds.
```

---

### Video 1B - Brand Promise (20 seconds)
**Word Count**: 50 words

```
On The Spot means exactly that - we come to your spot. Your home. 
Your office. Your schedule.

No packing. No transporting. No waiting. 

Just professional curtain cleaning that comes to you.

That's the On The Spot promise.
```

**Veo Prompt**:
```
Confident South African professional woman, 40s, navy blazer, modern 
office setting, speaking directly to camera with warm authority:

[INSERT SCRIPT]

Professional brand video, clean aesthetic, 20 seconds.
```

---

## 🛠️ SECTION 2: SERVICE EXPLANATION VIDEOS

### Video 2A - On-Site Process Overview (45 seconds)
**Word Count**: 110 words

```
Let me explain our on-site curtain cleaning process.

We use specialized, hospital-grade equipment designed specifically for 
fabric care. Our process deep-cleans every fiber while your curtains 
stay on the rails.

First, we assess your curtains - fabric type, stains, and specific 
care needs.

Second, we pre-treat any spots using eco-friendly solutions.

Third, our deep-cleaning removes dust, pollen, allergens, and that 
stubborn Johannesburg pollution.

The entire process takes two to four hours depending on the number 
of curtains. You can be home or away.

When we're finished, your curtains are fresh, clean, and beautiful. 
No removal. No damage. No disruption.
```

**Veo Prompt**:
```
[Upload photo of equipment or work scene]

Professional SA woman, 40s, navy blazer, explaining process while 
gesturing toward work scene or equipment:

[INSERT SCRIPT]

Educational video style, professional quality, 45 seconds.
```

---

### Video 2B - Why Choose Us (30 seconds)
**Word Count**: 75 words

```
Why choose On The Spot? Three simple reasons.

First - convenience. We come to your home or office when it suits you. 
No packing, no disruption.

Second - savings. You save up to sixty percent compared to traditional 
dry cleaning.

Third - expertise. Over a decade serving Johannesburg's most discerning 
clients.

That's why Sandton, Hyde Park, and Morningside trust On The Spot.
```

**Veo Prompt**:
```
Professional SA businesswoman, 40s, navy blazer, office setting, 
counting benefits on fingers while explaining confidently:

[INSERT SCRIPT]

Benefit-focused corporate video, 30 seconds.
```

---

### Video 2C - Mattress Sanitization (40 seconds)
**Word Count**: 95 words

```
Let's talk about your mattresses.

We spend a third of our lives in bed, but mattresses can harbor dust 
mites, allergens, and bacteria you can't see.

Our mattress sanitization service uses hospital-grade equipment. We 
deep-clean and sanitize, removing allergens and bacteria.

The results? Better sleep quality. Reduced allergies. Extended mattress 
life. A healthier bedroom environment.

Many clients bundle curtain and mattress cleaning on the same day. 
It's convenient, cost-effective, and gives you complete peace of mind.

Ask about our mattress service when you book.
```

**Veo Prompt**:
```
Professional SA woman, 40s, navy blazer, bedroom or home setting, 
explaining health benefits warmly and professionally:

[INSERT SCRIPT]

Health-focused professional video, caring tone, 40 seconds.
```

---

## 🏘️ SECTION 3: SUBURB-SPECIFIC VIDEOS

### Video 3A - Sandton (30 seconds)
**Word Count**: 70 words

```
To my Sandton neighbors - I understand your lifestyle.

Your days are full. Your home is your sanctuary. Those beautiful 
floor-to-ceiling curtains deserve the very best care.

We've built our service around your needs. Same-week appointments. 
Flexible scheduling. Quiet, efficient work that respects your space.

Discover why Sandton's most discerning homeowners choose On The Spot. 

Book your appointment today.
```

**Veo Prompt**:
```
[Upload photo of luxury Sandton home or estate]

Elegant SA professional woman, 40s, navy blazer, standing in front 
of upscale home setting, addressing affluent audience:

[INSERT SCRIPT]

Upscale brand video, sophisticated tone, 30 seconds.
```

---

### Video 3B - Hyde Park (25 seconds)
**Word Count**: 60 words

```
Hyde Park families, this message is for you.

Your neighborhood is special. Tree-lined streets. Beautiful homes. 
Real community.

Whether it's bay window curtains, dining room drapes, or nursery 
curtains - we handle every fabric with expert care.

Join your Hyde Park neighbors. Experience professional on-site 
cleaning.

We're here for you.
```

**Veo Prompt**:
```
Warm, approachable SA woman, 40s, navy blazer, residential 
neighborhood setting, speaking to community:

[INSERT SCRIPT]

Community-focused video, neighborly tone, 25 seconds.
```

---

### Video 3C - Morningside (25 seconds)
**Word Count**: 60 words

```
Morningside residents - quality matters to you.

Your area has some of Johannesburg's most beautiful homes and 
exquisite window treatments.

Our team specializes in luxury fabrics. Silk. Velvet. Damask. 
Custom imports. We handle them all with expert care.

Many Morningside homes trust us with curtains AND mattresses.

Schedule your appointment this week.
```

**Veo Prompt**:
```
Sophisticated SA professional, 40s, navy blazer, elegant home 
setting, emphasizing quality and expertise:

[INSERT SCRIPT]

Quality-focused video, refined tone, 25 seconds.
```

---

## 💫 SECTION 4: BEFORE/AFTER SHOWCASE

### Video 4A - Transformation Reveal (30 seconds)
**Word Count**: 75 words

```
Look at this incredible transformation!

These curtains from a Hyde Park home had years of dust and pollution. 
You can see how dull they'd become.

After just one On The Spot session? 

Colors restored. Every pleat fresh. Fabric draping beautifully again.

This entire cleaning was done on-site in under three hours. The curtains 
never left the rails.

This is what we do - bring your curtains back to life.

Book your transformation today.
```

**Veo Prompt**:
```
[Upload before/after split image]

Enthusiastic SA woman, 40s, navy blazer, presenting before/after 
results, pointing to differences with genuine excitement:

[INSERT SCRIPT]

Demonstration video, transformation reveal style, 30 seconds.
```

---

## 📱 SECTION 5: SOCIAL MEDIA SHORT-FORM

### Video 5A - Instagram Reel (15 seconds)
**Word Count**: 35 words

```
No removal needed! 

We clean your curtains right where they hang. Same day service. 
Professional results.

Serving Sandton, Hyde Park, Morningside.

Book now at On The Spot dot co dot za!
```

**Veo Prompt**:
```
Energetic SA woman, 40s, professional but approachable, quick 
dynamic presentation:

[INSERT SCRIPT]

Social media style, vertical format, upbeat energy, 15 seconds.
```

---

### Video 5B - TikTok Hook (10 seconds)
**Word Count**: 25 words

```
Wait - you're still taking curtains down to clean them?

There's a better way!

On The Spot cleans on-site. Watch this transformation!
```

**Veo Prompt**:
```
Conversational SA woman, 40s, speaking directly to camera with 
friendly surprise tone:

[INSERT SCRIPT]

TikTok style, attention-grabbing hook, 10 seconds.
```

---

### Video 5C - Facebook Quick Tip (20 seconds)
**Word Count**: 45 words

```
Quick tip: Your curtains collect more dust and allergens than you think.

We recommend professional cleaning every six to twelve months.

On The Spot makes it easy. We come to you. No removal needed.

Book your appointment today!
```

**Veo Prompt**:
```
Helpful SA professional, 40s, sharing expert advice warmly:

[INSERT SCRIPT]

Educational tip style, friendly professional, 20 seconds.
```

---

## ❓ SECTION 6: FAQ RESPONSES

### Video 6A - How Long Does It Take? (15 seconds)
**Word Count**: 35 words

```
Common question: "How long will it take?"

For most homes, two to four hours depending on the number of windows.

You can be home or away - whatever works for you.
```

**Veo Prompt**:
```
SA professional, 40s, answering question directly and helpfully:

[INSERT SCRIPT]

FAQ style, clear and concise, 15 seconds.
```

---

### Video 6B - Safe for Delicate Fabrics? (15 seconds)
**Word Count**: 35 words

```
"Is it safe for delicate fabrics?"

Absolutely! We handle silk, velvet, linen, even imported specialties.

Our team adjusts techniques for each fabric type.

Professional care you can trust.
```

**Veo Prompt**:
```
Confident SA expert, 40s, reassuring customers about fabric safety:

[INSERT SCRIPT]

Reassuring FAQ response, 15 seconds.
```

---

### Video 6C - Cost Savings (20 seconds)
**Word Count**: 45 words

```
"How much will I save?"

Up to sixty percent compared to traditional dry cleaning.

Plus, no petrol costs. No time driving to cleaners. No waiting weeks 
for results.

On-site cleaning saves you money AND time.
```

**Veo Prompt**:
```
SA professional explaining savings benefits clearly:

[INSERT SCRIPT]

Value-focused FAQ, benefit emphasis, 20 seconds.
```

---

## 📞 SECTION 7: CALLS-TO-ACTION

### Video 7A - Book Now (Strong CTA - 20 seconds)
**Word Count**: 50 words

```
Ready for beautifully clean curtains?

Click the button below for an instant quote. Just tell us your suburb 
and number of windows.

We serve all major Johannesburg areas with same-week appointments.

Don't wait - book your On The Spot service today!
```

**Veo Prompt**:
```
Encouraging SA professional, 40s, gesturing toward booking button, 
direct call-to-action energy:

[INSERT SCRIPT]

CTA video, action-oriented, 20 seconds.
```

---

### Video 7B - Special Offer (25 seconds)
**Word Count**: 55 words

```
Special offer for new clients!

Book this month and save twenty percent on your first curtain cleaning.

Plus, get a free mattress inspection when you bundle services.

This offer ends soon!

Click below to claim your discount and schedule your appointment.

Transform your home today!
```

**Veo Prompt**:
```
Excited SA professional, 40s, promotional energy, urgency without 
being pushy:

[INSERT SCRIPT]

Promotional video, limited offer style, 25 seconds.
```

---

### Video 7C - Thank You (15 seconds)
**Word Count**: 35 words

```
Thank you for choosing On The Spot Curtain Cleaning and Service.

We're grateful for your trust and committed to exceeding your expectations.

Questions? Reach out anytime.

See you soon!
```

**Veo Prompt**:
```
Warm, grateful SA professional, 40s, genuine appreciation:

[INSERT SCRIPT]

Thank you message, personal connection, 15 seconds.
```

---

## 🎥 SECTION 8: ON-SITE WORK OVERLAYS

### Video 8A - Work in Progress (30 seconds)
**Word Count**: 70 words

```
This is exactly what I was telling you about.

See our team in action? They're cleaning these beautiful drapes right 
on the rail using our specialized equipment.

Notice the difference already appearing? That's dust and grime being 
extracted from the fabric.

The homeowner can relax, knowing their curtains are in expert hands.

This could be your home next. Ready to experience On The Spot?
```

**Veo Prompt**:
```
[Upload photo of your team working on curtains]

SA professional woman, 40s, navy blazer, standing in front of work 
scene, pointing to team activity, explaining process:

[INSERT SCRIPT]

Real-work demonstration, authentic style, 30 seconds.
```

---

### Video 8B - Results Showcase (25 seconds)
**Word Count**: 60 words

```
Look at these results!

Fresh, clean curtains that look brand new. 

The client is thrilled. The room feels brighter. The fabric drapes 
perfectly again.

This transformation took just three hours. All done on-site. No 
removal needed.

This is what On The Spot delivers every single time.

Book your transformation now!
```

**Veo Prompt**:
```
[Upload photo of finished clean curtains]

Satisfied SA professional, 40s, presenting completed work with pride:

[INSERT SCRIPT]

Results showcase, satisfaction tone, 25 seconds.
```

---

## 📊 SECTION 9: BUSINESS/COMMERCIAL

### Video 9A - B2B Corporate (30 seconds)
**Word Count**: 75 words

```
Business leaders, let's talk about your professional environment.

Clean, well-maintained curtains communicate attention to detail and 
professional standards to your clients.

Our commercial service eliminates disruption. We work after hours or 
weekends. No impact on business operations.

We serve law firms, medical practices, corporate offices, and hospitality 
businesses across Johannesburg.

Request your commercial quote today.
```

**Veo Prompt**:
```
Professional SA businesswoman, 40s, corporate boardroom or office 
setting, speaking to business decision-makers:

[INSERT SCRIPT]

B2B corporate video, efficient professional tone, 30 seconds.
```

---

## 🎯 COMPLETE VEO PROMPT TEMPLATE

### **Universal Prompt Structure**:

```
[SETTING/IMAGE]
[If uploading photo: Upload work photo, home photo, or office photo]
[If generating: Describe setting in detail]

[CHARACTER]
Professional South African businesswoman, early 40s, wearing navy blue 
blazer with gold jewelry, [HAIRSTYLE: short professional style], warm 
brown skin tone, [POSE/ACTION: standing/gesturing/pointing/walking]

[SCRIPT]
She speaks to camera saying:
"[INSERT YOUR SCRIPT HERE - 30-150 WORDS]"

[TECHNICAL SPECS]
[STYLE: Corporate/Professional/Conversational/Enthusiastic]
[CAMERA: Medium shot/Full body/Close-up]
[LIGHTING: Bright natural/Soft office/Professional studio]
[QUALITY: Photorealistic, 1080p, professional production quality]
[DURATION: 15/20/25/30/45/60 seconds]
```

---

## ✅ PRODUCTION CHECKLIST

**For Each Video**:
- [ ] Select script (30-60 seconds)
- [ ] Adapt if needed (simplify, shorten)
- [ ] Choose setting (upload photo OR describe)
- [ ] Customize Veo prompt with script
- [ ] Generate video
- [ ] Download and review
- [ ] Upload to platforms

**Weekly Batch**:
- [ ] Monday: Generate 3-5 videos
- [ ] Tuesday: Review and select best
- [ ] Wednesday: Upload to YouTube
- [ ] Thursday: Deploy to website
- [ ] Friday: Share on social media

---

## 🎬 QUICK START: YOUR FIRST 5 VIDEOS

### **Video 1: Welcome** (Use Script 1A)
### **Video 2: Why Choose Us** (Use Script 2B)
### **Video 3: Sandton Pitch** (Use Script 3A)
### **Video 4: Before/After** (Use Script 4A)
### **Video 5: Book Now CTA** (Use Script 7A)

**Total Generation Time**: 30-60 minutes  
**Total Cost**: R0 (Veo free tier)  
**Immediate Deployment**: Upload to website, YouTube, social media

---

## 💡 VEO OPTIMIZATION TIPS

### **For Better Consistency**:
1. Generate first video with perfect Thandi
2. Save multiple screenshots as references
3. Upload reference image with each new script
4. Use identical prompt structure each time
5. Specify: "consistent with previous generation"

### **For Higher Quality**:
- Always include: "photorealistic, 1080p, professional quality"
- Specify lighting: "natural bright lighting" or "studio lighting"
- Add: "sharp focus, clear details, corporate video production"

### **For Emotional Range**:
- Welcome: "warm, welcoming smile"
- Excited: "enthusiastic energy, genuine excitement"
- Professional: "confident authority, expertise"
- Caring: "empathetic tone, reassuring presence"

---

## 📱 PLATFORM-SPECIFIC ADAPTATIONS

### **YouTube** (30-60 seconds):
- Use longer scripts (45-60s)
- More detailed explanations
- Educational tone
- End with strong CTA

### **Instagram/TikTok** (15-30 seconds):
- Shorter, punchier scripts
- Hook in first 3 seconds
- Visual focus
- Text overlay friendly

### **Facebook** (20-40 seconds):
- Conversational tone
- Community focused
- Shareable content
- Call-out specific suburbs

### **Website** (30-45 seconds):
- Professional quality
- Brand messaging
- Service explanations
- Clear CTAs

---

## 🎉 YOU'RE READY TO GENERATE!

**All scripts are optimized for Veo's 30-60 second format.**

**Copy any script above → Paste into Veo prompt → Generate → Deploy!**

**Need help adapting other scripts? Let me know!**

---

**VEO SCRIPT LIBRARY v1.0**  
**Optimized for Google Veo Generation**  
**On The Spot Curtain Cleaning & Service**  
**January 2026**
