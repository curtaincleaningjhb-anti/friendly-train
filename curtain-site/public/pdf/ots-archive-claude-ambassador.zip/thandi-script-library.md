# THANDI MBATHA - COMPLETE SCRIPT LIBRARY
## On The Spot Curtain Cleaning & Service

---

## CHARACTER VOICE GUIDE

### Accent & Pronunciation Notes
- **South African English**: Clear but distinctive
- **Key vowel sounds**: 
  - "day" pronounced closer to "die"
  - "home" with slight "hoom" quality
  - "yes" can be "yis" in casual moments
- **Rhythm**: Slightly slower than American English, more measured
- **Pitch**: Warm, mid-range, confident
- **Local references**: Always pronounce Johannesburg with emphasis on "JO-han-nes-burg" (not "Jo-HANN-esburg")

### Personality Traits in Speech
- **Professional but warm** - like a trusted family advisor
- **Never pushy** - informative and helpful
- **Local pride** - genuine love for Johannesburg and South Africa
- **Knowledge authority** - speaks confidently about fabric care
- **Empathetic** - understands busy lifestyles

---

## CORE SCRIPTS

### 1. MASTER WELCOME (60 seconds) - Website Homepage

**[THANDI walks into frame from left, professional navy blazer, warm smile]**

> "Good day! I'm Thandi Mbatha with On The Spot Curtain Cleaning and Service, and I'm so pleased to welcome you.
>
> [Gestures warmly to camera]
>
> For over a decade, we've been helping Johannesburg families and businesses keep their curtains, mattresses, and upholstery absolutely pristine - without the hassle of traditional cleaning methods.
>
> [Walks slightly forward]
>
> Here's what makes us different: We come to your home or office, and we clean your curtains right where they hang. No taking them down, no re-hanging, no weeks waiting for dry cleaners.
>
> [Counts on fingers]
>
> You save time. You save money - up to 60% compared to traditional dry cleaning. And you get professional results that last.
>
> [Points to viewer]
>
> Whether you're in Sandton, Hyde Park, Morningside, or anywhere across Johannesburg, we're ready to serve you. Let me show you what truly clean curtains look like."

**TIMING**: 0:55
**GESTURES**: Walk-in, warm welcome, counting, pointing
**TONE**: Welcoming, professional, confident

---

### 2. SERVICE DEEP DIVE - On-Site Curtain Cleaning (90 seconds)

**[THANDI standing center, beside visual of curtain cleaning equipment]**

> "Let me explain exactly how our on-site curtain cleaning works - because it's quite remarkable.
>
> [Gestures to equipment visual]
>
> We use specialized, hospital-grade cleaning equipment that's been designed specifically for fabric care. Our process deep-cleans every fiber while your curtains remain hanging on their rails.
>
> [Walks to demonstration area]
>
> First, we assess your curtains - the fabric type, any stains or problem areas, and the specific care they need.
>
> Second, we pre-treat any spots or stains using eco-friendly, fabric-safe solutions.
>
> Third, our deep-cleaning process removes dust, pollen, allergens, smoke residue, and that stubborn Johannesburg pollution that builds up over time.
>
> [Points to before/after comparison]
>
> Look at this transformation. These are actual curtains from a Sandton home - before and after just one cleaning session.
>
> [Steps closer to camera]
>
> The entire process typically takes 2 to 4 hours depending on the number of curtains. You can be home or away - whatever suits your schedule. And when we're finished, your curtains are fresh, clean, and ready to enjoy.
>
> [Gestures openly]
>
> No removal. No damage to delicate fabrics. No disruption to your home. That's the On The Spot promise."

**TIMING**: 1:28
**GESTURES**: Equipment demonstration, walk-through, before/after pointing, open hands
**TONE**: Educational, professional, detailed

---

### 3. SUBURB SERIES - SANDTON (45 seconds)

**[THANDI in elegant setting, professional but approachable]**

> "To my Sandton neighbors - I know your lifestyle.
>
> [Walks into frame]
>
> Your days are full. Your home is your sanctuary. And those beautiful floor-to-ceiling curtains in your townhouse or estate? They deserve the very best care.
>
> [Gestures to visual of luxury home]
>
> We understand that for you, convenience isn't a luxury - it's essential. That's why we've built our entire service around your needs.
>
> [Counts benefits]
>
> Same-week appointments. Flexible scheduling - mornings, afternoons, even weekends. And we work quietly and efficiently, respecting your space.
>
> [Points to camera]
>
> Many of your neighbors in Sandhurst, Morningside, Hyde Park - they trust us with their homes. We'd be honored to serve you too.
>
> Book your appointment today, and discover why Sandton's most discerning homeowners choose On The Spot."

**TIMING**: 0:42
**GESTURES**: Walk-in, luxury visual, counting, direct point
**TONE**: Upscale, understanding, respectful

---

### 4. SUBURB SERIES - HYDE PARK (40 seconds)

**[THANDI in warm, home-like setting]**

> "Hyde Park families, this message is for you.
>
> [Warm smile, gestures welcomingly]
>
> Your neighborhood is special - tree-lined streets, beautiful homes, a real sense of community. We've been proud to serve Hyde Park residents for years.
>
> [Walks to display]
>
> Whether it's those gorgeous bay window curtains, your formal dining room drapes, or the nursery curtains in your child's room - we handle every fabric with expert care.
>
> [Points to testimonial visual]
>
> Mrs. Khumalo on 3rd Avenue says we 'brought her curtains back to life.' The Johnsons on Oxford Road have been quarterly customers for three years.
>
> [Direct to camera]
>
> Join your Hyde Park neighbors. Experience the difference professional on-site cleaning makes. We're just a phone call away."

**TIMING**: 0:38
**GESTURES**: Welcoming, walking, pointing to testimonials
**TONE**: Community-focused, warm, neighborly

---

### 5. SUBURB SERIES - MORNINGSIDE (40 seconds)

**[THANDI in bright, modern setting]**

> "Morningside residents - we know what you value.
>
> [Professional stance]
>
> Quality. Attention to detail. Service that respects your home and your time.
>
> [Walks to window visual]
>
> Your area has some of Johannesburg's most beautiful homes - and some of the most exquisite window treatments. From custom-made drapes to imported linens, we've cleaned them all.
>
> [Gestures to certification]
>
> Our team is trained in specialty fabric care. We know how to handle silk, velvet, damask, and even delicate sheers without any damage.
>
> [Steps toward camera]
>
> Many Morningside homes trust us with both their curtains and their mattresses - bundling services for a complete home refresh.
>
> Schedule your appointment this week, and see why Morningside chooses On The Spot."

**TIMING**: 0:37
**GESTURES**: Professional stance, walking, certification display, stepping forward
**TONE**: Quality-focused, sophisticated, detail-oriented

---

### 6. SUBURB SERIES - BRYANSTON (40 seconds)

**[THANDI in professional corporate-style setting]**

> "Bryanston businesses and homeowners - let's talk efficiency.
>
> [Confident stance]
>
> You're in one of Johannesburg's premier commercial and residential areas. Your property makes a statement - and your curtains are part of that first impression.
>
> [Walks to split-screen: office vs. home]
>
> Whether it's your office boardroom drapes or your home's entertainment area, we provide the same meticulous service.
>
> [Points to business visual]
>
> For businesses: We work after hours if preferred. Minimal disruption. Professional results that impress clients.
>
> [Points to residential visual]
>
> For homes: Flexible weekday or weekend appointments that fit your schedule.
>
> [Direct to camera]
>
> Bryanston expects the best. That's exactly what we deliver. Contact us today."

**TIMING**: 0:38
**GESTURES**: Confident stance, walking, split pointing, direct address
**TONE**: Business-like, efficient, professional

---

### 7. BEFORE/AFTER SHOWCASE (60 seconds)

**[THANDI standing beside large before/after comparison screen]**

> "Let me show you the remarkable difference we make.
>
> [Points to 'BEFORE' side]
>
> This was a beautiful Hyde Park home. The owners loved their curtains - custom-made, expensive, elegant. But years of Johannesburg's dust, pollen, and pollution had taken their toll.
>
> [Traces finger along dulled fabric visual]
>
> You can see the colors have faded. There's visible dust accumulation in the pleats. And the fabric had lost that crisp, fresh appearance.
>
> [Walks to 'AFTER' side, gestures excitedly]
>
> After just one On The Spot cleaning session? Look at this transformation!
>
> [Points to details]
>
> Colors restored to their original vibrancy. Every pleat clean and fresh. The fabric drapes beautifully again. Even the room feels brighter.
>
> [Steps back to show full comparison]
>
> This entire cleaning was done on-site in under three hours. The curtains never left the rails. No removal, no stress, no weeks of waiting.
>
> [Walks toward camera]
>
> This is what we do - bring your curtains back to life. Let us show you what your curtains can look like. Book your transformation today."

**TIMING**: 0:58
**GESTURES**: Pointing, tracing, walking between sides, excited gestures, stepping back, approaching camera
**TONE**: Demonstrative, excited, transformational

---

### 8. MATTRESS CLEANING UPSELL (45 seconds)

**[THANDI in bedroom-style setting, professional but comfortable]**

> "While we're discussing complete home care, let me share something important about your mattresses.
>
> [Gestures to mattress visual]
>
> We spend a third of our lives in bed. But your mattress can harbor dust mites, allergens, dead skin cells, and odors that you can't see or smell - until they become a problem.
>
> [Walks to cleaning equipment display]
>
> Our mattress sanitization service uses the same hospital-grade equipment as our curtain cleaning. We deep-clean and sanitize, removing allergens and bacteria.
>
> [Counts benefits]
>
> Better sleep quality. Reduced allergies. Extended mattress life. And a fresher, healthier bedroom environment.
>
> [Steps toward camera]
>
> Many of our clients bundle curtain and mattress cleaning on the same day. It's convenient, cost-effective, and gives you complete peace of mind.
>
> Ask about our mattress service when you book your curtain cleaning - we'll make it easy."

**TIMING**: 0:43
**GESTURES**: Bedroom gesture, walking, equipment display, counting, stepping forward
**TONE**: Health-focused, caring, informative

---

### 9. PERSIAN RUG CLEANING (60 seconds)

**[THANDI in elegant room with rug display]**

> "Your Persian rug is more than a floor covering - it's an investment, a work of art, a family treasure.
>
> [Kneels beside rug visual, touches gently]
>
> These exquisite pieces deserve specialized care from people who understand their value. That's where our expertise makes all the difference.
>
> [Stands, gestures to cleaning process visual]
>
> We clean Persian and Oriental rugs using traditional methods combined with modern technology. Hand washing. Gentle, fiber-safe solutions. Meticulous attention to colors and patterns.
>
> [Walks to before/after comparison]
>
> Look at this Tabriz rug from a Sandton collector. Before cleaning, years of foot traffic had dulled the colors. After our care? The intricate patterns shine, the colors are vibrant, the wool is soft again.
>
> [Points to certification]
>
> Our team has trained specifically in Persian rug care. We understand the difference between a Kashan and a Qom, between wool and silk foundations.
>
> [Stands beside rug]
>
> Whether your rug needs a routine cleaning or requires stain removal and restoration, we have the expertise. Protect your investment. Let us care for your Persian treasures."

**TIMING**: 0:57
**GESTURES**: Kneeling, gentle touching, standing, walking, pointing, standing beside
**TONE**: Reverent, expert, gentle, knowledgeable

---

### 10. UPHOLSTERY CLEANING (50 seconds)

**[THANDI in living room setting with furniture]**

> "Your furniture tells your story - family gatherings, movie nights, quiet reading corners.
>
> [Gestures to sofa]
>
> But everyday life takes its toll. Spills. Pet hair. Body oils. Dust. Your beautiful upholstery can start looking tired.
>
> [Walks around furniture]
>
> We specialize in on-site upholstery cleaning for sofas, chairs, dining chairs, even office furniture. Same principle as our curtain service - we come to you.
>
> [Points to fabric close-up]
>
> Our process is safe for all fabric types - microfiber, leather, velvet, linen. We pre-treat stains, deep-clean the fabric, and extract moisture so everything dries quickly.
>
> [Sits on furniture edge]
>
> Most pieces are ready to use again within hours, not days. No hauling furniture anywhere. No rental fees for temporary seating.
>
> [Stands, faces camera]
>
> Give your furniture a second life. Let us restore what you love. Book your upholstery cleaning today."

**TIMING**: 0:48
**GESTURES**: Sofa gesture, walking around, pointing, sitting, standing
**TONE**: Homely, practical, caring

---

### 11. SEASONAL CAMPAIGN - SPRING CLEANING (40 seconds)

**[THANDI in bright, fresh setting with spring flowers]**

> "Spring has arrived in Johannesburg - and that means it's time to refresh your home!
>
> [Gestures to window with sunshine]
>
> After winter's closed windows and heaters, your curtains have absorbed months of dust and indoor air. Now's the perfect time for a deep clean.
>
> [Walks with energy]
>
> Our Spring Refresh Special includes curtain cleaning, optional mattress sanitization, and upholstery care - all at special seasonal pricing.
>
> [Points to calendar]
>
> Book this month and receive 15% off when you bundle two or more services. Plus, priority scheduling to get your home fresh before the holidays.
>
> [Direct to camera, cheerful]
>
> Welcome spring with clean, fresh curtains. Limited time offer - book your Spring Refresh today!"

**TIMING**: 0:38
**GESTURES**: Spring gestures, energetic walking, calendar pointing, cheerful direct address
**TONE**: Energetic, seasonal, promotional

---

### 12. COMMERCIAL/B2B PITCH (60 seconds)

**[THANDI in corporate office setting, professional blazer]**

> "Business leaders, let's discuss your professional environment.
>
> [Confident stance, gestures to office]
>
> Your office space makes a statement to clients, partners, and employees. Clean, well-maintained curtains and upholstery communicate attention to detail and professional standards.
>
> [Walks to boardroom visual]
>
> But taking down commercial curtains for cleaning? That means disruption, coordination headaches, and potential damage.
>
> [Points to solution visual]
>
> Our commercial on-site service eliminates those problems. We work after hours or on weekends. No disruption to your business operations. Professional results that enhance your environment.
>
> [Walks to different office areas]
>
> Reception areas. Boardrooms. Executive offices. Conference facilities. We handle it all with discretion and efficiency.
>
> [Returns to center, faces camera]
>
> We serve law firms, medical practices, corporate offices, and hospitality businesses across Johannesburg. Join companies who trust On The Spot for their professional image.
>
> [Extends hand gesture]
>
> Request a commercial quote today. Let's discuss how we can serve your business."

**TIMING**: 0:58
**GESTURES**: Confident stance, office gestures, walking, pointing, professional extension
**TONE**: Corporate, professional, solution-focused

---

### 13. FAQ - HOW LONG DOES IT TAKE? (30 seconds)

**[THANDI in casual, friendly setting]**

> "One of our most common questions: 'How long will it take?'
>
> [Friendly smile]
>
> Great question! For most homes, curtain cleaning takes between 2 to 4 hours, depending on the number of windows.
>
> [Counts on fingers]
>
> One or two rooms? About 2 hours. Whole house with 6-8 windows? Around 4 hours.
>
> [Points to viewer]
>
> You can be home or away - whatever works for you. We're efficient, respectful, and thorough.
>
> Book your appointment and we'll give you an exact time estimate based on your specific needs."

**TIMING**: 0:28
**GESTURES**: Friendly smile, counting, pointing
**TONE**: Casual, helpful, clear

---

### 14. FAQ - IS IT SAFE FOR DELICATE FABRICS? (30 seconds)

**[THANDI holding fabric samples]**

> "Worried about your delicate fabrics? You should be careful - not all cleaners know how to handle specialty materials.
>
> [Holds up silk sample]
>
> We clean everything from everyday cotton to precious silk, velvet, and imported linens. Our team is trained in fabric identification and appropriate care methods.
>
> [Gestures to equipment]
>
> We adjust our equipment, solutions, and techniques based on your specific fabric type. No guesswork - just expert care.
>
> [Reassuring smile]
>
> If we can't clean a fabric safely, we'll tell you upfront. Honesty and expertise - that's our promise."

**TIMING**: 0:29
**GESTURES**: Holding samples, equipment gesture, reassuring expression
**TONE**: Expert, reassuring, honest

---

### 15. FAQ - WHAT ABOUT STAINS? (35 seconds)

**[THANDI beside stain removal visual]**

> "Stains happen - red wine, coffee, ink, even little ones' markers.
>
> [Points to stain examples]
>
> Our process includes pre-treatment of all visible stains using specialized, fabric-safe solutions. Many stains we can remove completely. Some older or set-in stains may lighten but not disappear entirely.
>
> [Honest expression]
>
> We'll always be honest about what we can achieve. We assess every stain before we start and set realistic expectations.
>
> [Positive gesture]
>
> But most clients are amazed at how much better their curtains look - even with stubborn stains significantly improved.
>
> Let us evaluate your stains. You might be pleasantly surprised!"

**TIMING**: 0:34
**GESTURES**: Pointing to examples, honest expression, positive gesture
**TONE**: Honest, realistic, hopeful

---

### 16. TESTIMONIAL INTRODUCTION (20 seconds)

**[THANDI warmly introducing testimonial segment]**

> "Don't just take my word for it. Listen to what your Johannesburg neighbors have to say.
>
> [Gestures to testimonial video/quote]
>
> This is Mrs. Naidoo from Sandton. She's been our client for two years. Here's what she told us..."

**[TRANSITION TO CLIENT TESTIMONIAL VIDEO]**

**TIMING**: 0:18
**GESTURES**: Warm gesture to testimonial
**TONE**: Warm, proud, transitional

---

### 17. CALL-TO-ACTION - BOOKING (30 seconds)

**[THANDI energetic, direct to camera]**

> "Ready to see what truly clean curtains look like?
>
> [Steps closer to camera]
>
> Booking is simple. Click the button below for an instant online quote - just tell us how many windows you have and your suburb.
>
> [Points to booking button visual]
>
> Or call us directly at [PHONE NUMBER]. We'll answer your questions and schedule your appointment.
>
> [Enthusiastic gesture]
>
> We serve all major Johannesburg suburbs with same-week appointments available. Don't wait - book your On The Spot service today!
>
> [Warm smile]
>
> I look forward to serving you."

**TIMING**: 0:29
**GESTURES**: Stepping closer, pointing to button, enthusiastic gesture, warm smile
**TONE**: Energetic, action-oriented, warm closing

---

### 18. CALL-TO-ACTION - SPECIAL OFFER (25 seconds)

**[THANDI with promotional energy]**

> "Special offer for new clients - book this month and save!
>
> [Excited gesture]
>
> 20% off your first curtain cleaning service, plus a free mattress inspection when you bundle.
>
> [Points to offer details]
>
> But this offer ends soon. Click below to claim your discount and schedule your appointment.
>
> [Direct point to viewer]
>
> Don't miss out - transform your home today!"

**TIMING**: 0:23
**GESTURES**: Excited gesture, pointing to details, direct point
**TONE**: Promotional, urgent, exciting

---

### 19. THANK YOU / FOLLOW-UP (20 seconds)

**[THANDI warm, grateful]**

> "Thank you for choosing On The Spot Curtain Cleaning and Service.
>
> [Hand on heart]
>
> We're grateful for your trust, and we're committed to exceeding your expectations.
>
> [Gestures welcomingly]
>
> If you have any questions before your appointment, don't hesitate to reach out. We're here to help.
>
> [Warm smile]
>
> See you soon!"

**TIMING**: 0:18
**GESTURES**: Hand on heart, welcoming gesture, warm smile
**TONE**: Grateful, warm, personal

---

### 20. ON-SITE VIDEO OVERLAY (30 seconds)

**[THANDI appears beside actual job site footage]**

> "This is exactly what I was telling you about.
>
> [Points to technician working]
>
> Look at our team in action - cleaning these beautiful drapes right on the rail. You can see the specialized equipment we use.
>
> [Points to before area]
>
> Notice the difference already appearing? That's the dust and grime being extracted from the fabric.
>
> [Gestures to happy homeowner in background]
>
> And the homeowner can relax, knowing their curtains are in expert hands.
>
> [Faces camera]
>
> This could be your home next. Ready to experience the On The Spot difference?"

**TIMING**: 0:29
**GESTURES**: Pointing to action, pointing to results, welcoming gesture, direct address
**TONE**: Demonstrative, real-time, engaging

---

## PLATFORM-SPECIFIC VARIATIONS

### INSTAGRAM REELS (15-30 seconds max)

**Example: Quick Service Intro**
> "On-site curtain cleaning? Yes! We clean while they hang. No removal needed. Sandton to Bryanston - we serve you. Book now! 🌟"

**TIMING**: 0:12
**STYLE**: Fast-paced, energetic, emoji-friendly

---

### TIKTOK (15-60 seconds, trending style)

**Example: Before/After Wow**
> "POV: You thought your curtains were 'clean enough'... 😬
>
> [Shows dull curtains]
>
> Until we showed up! 
>
> [Shows transformation]
>
> WAIT FOR IT... ✨
>
> Same curtains. Same day. No removal. Just pure magic.
>
> That's On The Spot. Book in bio! 💫"

**TIMING**: 0:20
**STYLE**: Trendy, surprising, visually driven

---

### YOUTUBE (60-180 seconds, educational)

**Example: Full Service Walkthrough**
[Extended version of Service Deep Dive script with more detail, demonstrations, and technical explanations]

**TIMING**: 2:00-3:00
**STYLE**: Educational, detailed, authoritative

---

### EMAIL MARKETING (20-40 seconds)

**Example: Personalized Quote Follow-up**
> "Hi [Name], this is Thandi from On The Spot.
>
> Thank you for requesting a quote for your home in [Suburb]. I've reviewed your needs, and I'm excited to help.
>
> [Shows quote details]
>
> Your custom quote includes [X] windows of curtain cleaning for [PRICE]. We can schedule as early as [DATE].
>
> Click below to confirm your appointment, or reply if you have questions.
>
> I look forward to serving you!"

**TIMING**: 0:35
**STYLE**: Personalized, direct, warm

---

## VOICE DIRECTION NOTES FOR VOICE ARTISTS

### General Guidelines
- **Pace**: Slightly slower than conversational - allow words to resonate
- **Emphasis**: Key brand terms: "On The Spot," suburb names, "on-site," "no removal"
- **Emotion**: Genuine warmth without being saccharine
- **Energy**: Professional energy - not high-energy sales, but engaged and present

### Specific Moments
- **"Good day"**: Warm, traditional South African greeting - smile in voice
- **Listing benefits**: Clear enumeration, slight pause between points
- **Before/After reveals**: Building excitement, reveal with satisfaction
- **Calls-to-action**: Confident, direct, encouraging (not pushy)
- **Sign-offs**: Genuine warmth, like saying goodbye to a friend

### Pronunciation Guide
- **Johannesburg**: jo-HAN-nes-burg (stress on second syllable)
- **Sandton**: SAND-ton (not "Sandtown")
- **On The Spot**: Slight emphasis on "Spot" - brand name pride

---

## MUSIC & SOUND DESIGN RECOMMENDATIONS

### Background Music Style
- **Tempo**: 80-110 BPM
- **Genre**: Uplifting corporate, light acoustic, positive ambient
- **Volume**: -20dB to -25dB (subtle, not competing with voice)
- **Avoid**: Heavy bass, distracting melodies, anything too energetic

### Sound Effects (subtle)
- **Whoosh transitions**: Between scenes/topics
- **Success chimes**: After before/after reveals
- **Gentle button sounds**: For CTAs
- **Ambient room tone**: For realism in on-site videos

---

## VIDEO PRODUCTION SPECIFICATIONS

### Technical Requirements
- **Resolution**: 1080p minimum, 4K preferred
- **Aspect Ratios**:
  - Website: 16:9 (landscape)
  - Instagram/TikTok: 9:16 (vertical)
  - Square posts: 1:1
- **Frame Rate**: 30fps or 60fps
- **File Format**: MP4 (H.264 codec)
- **Audio**: AAC, 192kbps, stereo

### Visual Elements
- **Brand Colors**: Navy #1e3a8a, Gold #d4af37
- **Lower Thirds**: Name, title, website URL
- **Captions**: Always include (accessibility + silent viewing)
- **Logo**: Bottom right corner, subtle, always visible

---

**END OF SCRIPT LIBRARY**
**Version 1.0 - January 2026**
**On The Spot Curtain Cleaning & Service**
**Your Brand Ambassador: Thandi Mbatha**
