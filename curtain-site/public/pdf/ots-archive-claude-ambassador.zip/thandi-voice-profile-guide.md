# THANDI MBATHA - VOICE PROFILE & SOURCING GUIDE
## Finding the Perfect South African Voice for Your AI Avatar

---

## 🎤 VOICE CHARACTERISTICS

### Core Voice Profile

**Age Range**: 40-45 years  
**Gender**: Female  
**Accent**: South African English (General/Neutral with subtle influences)  
**Tone**: Warm, professional, trustworthy  
**Energy**: Medium-high (engaged but not hyperactive)  
**Pitch**: Medium (not too high, not too low)  
**Pace**: Moderate (clear and easy to understand)  

### South African Accent Specifics

#### Key Characteristics to Look For:

1. **Vowel Sounds**
   - "day" → sounds closer to "die" (diphthong shift)
   - "no" → more of an "ah" quality ("nah-oo")
   - "yes" → softer, sometimes "yis"
   - "now" → distinct "nah-oo" pronunciation

2. **Consonants**
   - Clear "r" sounds (not as rolled as Afrikaans, not as soft as British)
   - Crisp "t" sounds at the end of words
   - Slight emphasis on hard consonants

3. **Intonation Patterns**
   - Slight upward inflection at the end of statements (characteristic of SA English)
   - Measured, deliberate delivery
   - Natural warmth without being overly casual

4. **Rhythm & Cadence**
   - Slightly slower than American English
   - Deliberate pauses between phrases
   - Each word given proper weight

5. **Cultural Markers**
   - "Good day" instead of "Hello" (traditional greeting)
   - Subtle Zulu or Afrikaans influences (click sounds occasionally, guttural "g")
   - References to local places pronounced correctly

---

## 🎯 WHERE TO FIND THE PERFECT VOICE

### Option 1: Professional Voice Actors (Best Quality)

#### **1. Voices.com**
- **URL**: https://www.voices.com
- **Search**: "South African Female 40s Professional"
- **Filter**: English (South African), Corporate/Professional category
- **Cost**: $100-$500 per project (one-time)
- **Pros**: Professional quality, multiple takes, custom recordings
- **Cons**: Higher cost, but worth it for brand consistency

**Recommended Search Terms**:
- "South African female corporate"
- "Professional Johannesburg accent"
- "SA English narrator 40s"

#### **2. Fiverr Voice Actors**
- **URL**: https://www.fiverr.com/categories/music-audio/voice-overs
- **Search**: "South African voice over female"
- **Cost**: $50-$200 for professional level
- **Pros**: Affordable, quick turnaround, hear samples first
- **Cons**: Quality varies, need to vet carefully

**Top-Rated SA Voice Actors on Fiverr**:
1. Search for verified Pro sellers
2. Listen to ALL demo reels
3. Look for 500+ reviews and 4.9+ rating
4. Request custom sample before full order

#### **3. The Voice Realm (SA Specific)**
- **URL**: https://www.thevoicerealm.com
- **Focus**: South African voice talent marketplace
- **Cost**: R800-R2,500 per project
- **Pros**: All SA-based talent, understand local nuances
- **Cons**: Smaller pool, may need longer search

#### **4. Voquent**
- **URL**: https://www.voquent.com
- **Filter**: South Africa → Female → 40-45
- **Cost**: £100-£400 per project
- **Pros**: High-quality demos, professional management
- **Cons**: International pricing (GBP)

---

### Option 2: Voice Cloning Services (AI-Powered)

#### **1. ElevenLabs (Recommended for D-ID)**
- **URL**: https://elevenlabs.io
- **Cost**: $5-$99/month (subscription)
- **How It Works**:
  1. Record or source 1-3 minutes of sample voice
  2. Upload to ElevenLabs
  3. AI creates cloned voice
  4. Generate unlimited speech

**Steps**:
1. **Find a Voice Sample**:
   - YouTube interviews of SA professionals
   - Podcast clips (ensure legal rights)
   - Record a friend/colleague (with permission)
   - Hire voice actor for sample recording

2. **Upload to ElevenLabs**:
   - Need clean audio (no background noise)
   - 1-3 minutes minimum
   - Multiple emotions (happy, serious, excited)

3. **Clone & Test**:
   - Generate test sentences
   - Adjust settings (stability, clarity, style)
   - Save as custom voice for D-ID integration

**Pros**:
- Unlimited generation after initial clone
- Perfect for high-volume content
- Cost-effective long-term

**Cons**:
- Requires quality source audio
- Some trial and error to get right
- Legal considerations (ensure voice rights)

#### **2. Resemble.AI**
- Similar to ElevenLabs
- Slightly better at emotional range
- $29-$199/month

#### **3. Murf.AI**
- Pre-built SA voices available
- Try before cloning
- $29-$99/month

---

### Option 3: Stock Voice Libraries (D-ID Built-In)

#### **D-ID Studio Voice Library**
- D-ID has built-in text-to-speech voices
- Check for "South African English" options
- **Pros**: No extra setup, immediate use
- **Cons**: May not have perfect 40s female option

#### **Microsoft Azure (TTS)**
- Partner with D-ID
- "en-ZA" voices (South Africa)
- Female voices: "Leah", "Thandi"
- **Test First**: Some sound too young or robotic

#### **Google Cloud TTS**
- "en-ZA-Standard-A" (Female)
- "en-ZA-Wavenet-A" (Higher quality female)
- Integrates with D-ID

---

## 📝 RECORDING YOUR OWN VOICE SAMPLE

If you hire a voice actor or want to create a custom voice clone, here's how to get the best recording:

### Recording Script for Voice Cloning (Read Naturally)

```
"Good day! I'm Thandi Mbatha with On The Spot Curtain Cleaning and Service. 
We're Johannesburg's premium on-site curtain cleaning specialists.

Let me tell you about our services. We clean your curtains right where 
they hang - no removal, no hassle. Whether you're in Sandton, Hyde Park, 
or Morningside, we come to you.

Our process is simple. First, we assess your curtains. Then, we deep-clean 
using specialized equipment. Finally, you enjoy fresh, beautiful curtains 
that look brand new.

Imagine your home with perfectly clean curtains. No dust. No allergens. 
Just crisp, vibrant fabrics that transform your space.

Book your appointment today! We offer same-week service across Johannesburg. 
Visit our website or call us now. I look forward to serving you!"
```

### Recording Requirements:

1. **Environment**:
   - Quiet room (no echo, no background noise)
   - Close windows, turn off fans/AC
   - Use blankets/pillows to dampen sound

2. **Equipment**:
   - USB microphone (Blue Yeti, Audio-Technica AT2020)
   - OR smartphone in quiet space (surprisingly good quality)
   - Pop filter (or DIY with nylon stocking)

3. **Recording Settings**:
   - 44.1kHz or 48kHz sample rate
   - WAV or FLAC format (lossless)
   - Mono (single channel)
   - Speak 6-8 inches from microphone

4. **Performance**:
   - Natural, conversational tone
   - Smile while speaking (changes voice quality)
   - Vary emotion: professional, warm, excited, serious
   - Record multiple takes

5. **Editing**:
   - Remove mouth clicks/breathing sounds
   - Normalize volume
   - Export as high-quality WAV

---

## 🔍 VOICE ACTOR EVALUATION CHECKLIST

When listening to voice samples, rate each on 1-10:

- [ ] **Authentic SA Accent** (not exaggerated, not British/American)
- [ ] **Age-Appropriate** (sounds 40s, not 20s or 60s)
- [ ] **Professional Tone** (corporate, trustworthy, not casual)
- [ ] **Warm & Approachable** (friendly, not cold or salesy)
- [ ] **Clear Articulation** (easy to understand, no mumbling)
- [ ] **Energy Level** (engaged, not flat or overly excited)
- [ ] **Recording Quality** (clean audio, no background noise)
- [ ] **Consistency** (same quality across different samples)
- [ ] **Emotional Range** (can vary tone for different scripts)
- [ ] **Local Knowledge** (pronounces SA place names correctly)

**Minimum Score**: 80/100 to proceed  
**Ideal Score**: 90+/100

---

## 💰 COST COMPARISON

### One-Time Voice Actor Recording
- **Fiverr**: $50-$150
- **Voices.com**: $100-$500
- **Local SA Actor**: R800-R2,500
- **Professional Studio**: R3,000-R8,000

### Monthly Voice Cloning Subscription
- **ElevenLabs**: $5-$99/month (unlimited after clone)
- **Resemble.AI**: $29-$199/month
- **Murf.AI**: $29-$99/month

### D-ID Costs (Video Generation)
- **Creator Plan**: $29/month (up to 20 videos)
- **Pro Plan**: $49/month (up to 100 videos)
- **Advanced**: Custom pricing (unlimited)

### Total Estimated First Year Cost:
- **Setup**: R2,500-R7,500 (voice + avatar image)
- **Monthly**: R900-R1,800 (D-ID + voice cloning)
- **First Year Total**: ~R15,000-R28,000

**Compare to Traditional Video**:
- Professional video shoot: R25,000-R55,000 PER VIDEO
- **ROI**: Positive after 2-3 videos generated

---

## 🎬 VOICE INTEGRATION WITH D-ID

### Method 1: ElevenLabs + D-ID (Recommended)

```javascript
// 1. Clone voice in ElevenLabs
// 2. Get voice ID
const ELEVENLABS_VOICE_ID = 'your-custom-voice-id';

// 3. Use in D-ID API
const payload = {
  script: {
    type: 'text',
    input: 'Your script here',
    provider: {
      type: 'elevenlabs',
      voice_id: ELEVENLABS_VOICE_ID
    }
  },
  source_url: 'https://yoursite.com/thandi-image.jpg'
};
```

### Method 2: Upload Custom Audio

```javascript
// Record/generate audio separately
// Upload audio file to D-ID
const payload = {
  script: {
    type: 'audio',
    audio_url: 'https://yoursite.com/thandi-audio.mp3'
  },
  source_url: 'https://yoursite.com/thandi-image.jpg'
};
```

### Method 3: D-ID Built-In TTS

```javascript
// Use D-ID's Microsoft Azure voices
const payload = {
  script: {
    type: 'text',
    input: 'Your script here',
    provider: {
      type: 'microsoft',
      voice_id: 'en-ZA-LeahNeural' // SA Female voice
    }
  },
  source_url: 'https://yoursite.com/thandi-image.jpg'
};
```

---

## 📋 RECOMMENDED WORKFLOW

### Week 1: Voice Sourcing
1. **Day 1-2**: Listen to 20+ voice actor samples
2. **Day 3**: Shortlist top 3-5 candidates
3. **Day 4**: Request custom test reads (30 seconds each)
4. **Day 5**: Select final voice

### Week 2: Voice Recording/Cloning
1. **Day 1**: Hire voice actor or record sample
2. **Day 2-3**: Record complete script library (3-5 minutes)
3. **Day 4**: Upload to ElevenLabs for cloning
4. **Day 5**: Test cloned voice with various scripts

### Week 3: Avatar Integration
1. **Day 1**: Generate Thandi avatar image
2. **Day 2**: Set up D-ID account
3. **Day 3**: Upload avatar + voice to D-ID
4. **Day 4**: Generate first test video
5. **Day 5**: Review and refine

### Week 4: Production
1. **Day 1-3**: Generate all core videos
2. **Day 4**: Edit and add overlays
3. **Day 5**: Upload to website and social media

---

## 🎯 VOICE PROFILE FINE-TUNING

### ElevenLabs Voice Settings (If Using Clone):

**Stability**: 75-85%
- Lower = More expressive but less consistent
- Higher = More consistent but less emotional

**Clarity + Similarity Enhancement**: 70-80%
- Balances natural sound with clarity

**Style Exaggeration**: 0-20%
- Keep low for professional corporate tone

**Speaker Boost**: ON
- Enhances vocal clarity

### Test Sentences for Voice Quality:

```
1. "Good day! I'm Thandi Mbatha with On The Spot."
   [Check: Natural greeting, name pronunciation, brand clarity]

2. "We serve Sandton, Hyde Park, Morningside, and Bryanston."
   [Check: Place name pronunciation, list clarity]

3. "Your curtains will look absolutely beautiful and fresh."
   [Check: Emotional warmth, enthusiasm, descriptive language]

4. "Book your appointment today at On The Spot dot co dot za."
   [Check: Call-to-action energy, website pronunciation]

5. "Johannesburg's premier on-site curtain cleaning specialists."
   [Check: Professional terminology, brand positioning]
```

Listen for:
- ✅ Natural South African accent
- ✅ Consistent energy across sentences
- ✅ Clear pronunciation of brand/place names
- ✅ Appropriate emotional tone
- ✅ No robotic artifacts

---

## 📞 VOICE ACTOR BRIEF TEMPLATE

When hiring a voice actor, send this brief:

---

**PROJECT**: AI Avatar Voice for On The Spot Curtain Cleaning
**CHARACTER**: Thandi Mbatha - Brand Ambassador
**VOICE TYPE**: South African Female, 40s, Professional

**Character Description**:
Thandi is a knowledgeable, warm, and professional brand ambassador for a luxury curtain cleaning service in Johannesburg. She's like a trusted advisor - someone who genuinely cares about helping clients but maintains professional boundaries. She has a slight maternal warmth but is never patronizing.

**Tone**: Professional corporate, warm, trustworthy, confident
**Energy**: Medium-high (engaged, not hyperactive)
**Accent**: Authentic South African English (not exaggerated)

**Key Pronunciations**:
- Johannesburg: jo-HAN-nes-burg
- Sandton: SAND-ton
- On The Spot: (slight emphasis on "Spot")

**Sample Script**: [Include 2-3 scripts from library]

**Deliverables**:
- 3-5 minutes of recorded speech
- Multiple emotional ranges (warm/professional/excited)
- Clean audio (WAV format, 48kHz)
- Full commercial usage rights

**Budget**: $[Amount]
**Deadline**: [Date]

---

## ✅ FINAL CHECKLIST

Before finalizing your voice:

- [ ] Listened to at least 10 voice samples
- [ ] Selected voice that scores 90+ on evaluation checklist
- [ ] Confirmed authentic South African accent
- [ ] Tested voice with your actual scripts
- [ ] Verified age-appropriate (sounds 40s)
- [ ] Confirmed professional tone (not too casual)
- [ ] Ensured warm but not overly friendly
- [ ] Checked pronunciation of key terms
- [ ] Obtained full commercial usage rights
- [ ] Saved high-quality audio files (WAV/FLAC)
- [ ] Successfully cloned voice (if using AI)
- [ ] Generated test video with D-ID
- [ ] Reviewed video quality with team
- [ ] Approved for production

---

## 🎤 CONCLUSION

The voice of Thandi Mbatha is crucial to your brand identity. Take the time to find the perfect voice - it's worth the investment. A great voice will:

1. Build instant trust with viewers
2. Create consistency across all videos
3. Represent your brand professionally
4. Connect with your Johannesburg audience
5. Scale effortlessly as you grow

**Recommended Path**: 
Hire a professional SA voice actor for initial recording → Clone with ElevenLabs → Integrate with D-ID → Generate unlimited videos

**Budget-Friendly Path**:
Use D-ID's built-in SA voice (en-ZA-LeahNeural) → Test with audience → Upgrade to custom voice if needed

**Premium Path**:
Hire top SA voice actor → Professional studio recording → ElevenLabs clone → D-ID integration → Brand consistency achieved

---

**Good luck finding Thandi's voice! She's out there waiting to represent On The Spot.**

*For questions or assistance, refer to the main Avatar Ambassador System documentation.*
